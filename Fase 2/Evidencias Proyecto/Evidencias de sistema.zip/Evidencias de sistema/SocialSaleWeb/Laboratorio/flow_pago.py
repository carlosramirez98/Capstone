
"""Cliente de la API de Flow. No modifica pagos en PostgreSQL."""

import hashlib
import hmac
import os
import re
from pathlib import Path
from urllib.parse import quote, urlsplit

import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent / ".env")


class FlowAPIError(RuntimeError):
    pass


class FlowHTTPError(FlowAPIError):
    pass


def configuracion_flow():
    key = os.getenv("FLOW_API_KEY", "").strip()
    secret = os.getenv("FLOW_SECRET_KEY", "").strip()
    base = os.getenv("FLOW_API_URL", "").strip().rstrip("/")

    if not key or not secret:
        raise FlowAPIError("Faltan credenciales de Flow")

    if base not in (
        "https://www.flow.cl/api",
        "https://sandbox.flow.cl/api"
    ):
        raise FlowAPIError("URL de Flow no válida")

    return key, secret, base


def firmar_flow(parametros, secret):
    cadena = "".join(
        f"{clave}{parametros[clave]}"
        for clave in sorted(parametros)
    )

    return hmac.new(
        secret.encode("utf-8"),
        cadena.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()


def consultar_api_flow(endpoint, parametros, metodo="GET"):
    key, secret, base = configuracion_flow()

    datos = {
        clave: str(valor)
        for clave, valor in parametros.items()
    }

    datos["apiKey"] = key
    datos["s"] = firmar_flow(datos, secret)

    try:
        if metodo == "POST":
            respuesta = requests.post(
                f"{base}/{endpoint}",
                data=datos,
                timeout=(5, 20)
            )
        else:
            respuesta = requests.get(
                f"{base}/{endpoint}",
                params=datos,
                timeout=(5, 20)
            )

        try:
            respuesta.raise_for_status()
        except requests.HTTPError as error:
            if 400 <= respuesta.status_code < 500:
                raise FlowHTTPError(
                    "Flow rechazó la solicitud"
                ) from error
            raise

        resultado = respuesta.json()

    except FlowHTTPError:
        raise
    except (requests.RequestException, ValueError) as error:
        raise FlowAPIError(
            "No se pudo consultar Flow de forma segura"
        ) from error

    if not isinstance(resultado, dict):
        raise FlowAPIError("Respuesta inesperada de Flow")

    return resultado


def crear_pago_flow(
    orden,
    monto,
    correo,
    url_confirmacion,
    url_retorno,
    timeout_segundos=1200
):

    if (
        isinstance(monto, bool)
        or not isinstance(monto, int)
        or monto <= 0
    ):
        raise ValueError("Monto inválido")

    if not orden or len(str(orden)) > 100:
        raise ValueError("Orden inválida")

    for url in (url_confirmacion, url_retorno):
        partes = urlsplit(url)

        if (
            partes.scheme != "https"
            or not partes.hostname
            or partes.username
            or partes.password
        ):
            raise ValueError("Se requieren URLs HTTPS")

    resultado = consultar_api_flow(
        "payment/create",
        {
            "commerceOrder": orden,
            "subject": f"Pedido SocialSale {orden}",
            "currency": "CLP",
            "amount": monto,
            "email": correo,
            "urlConfirmation": url_confirmacion,
            "urlReturn": url_retorno,
            "timeout": timeout_segundos
        },
        "POST"
    )

    url = resultado.get("url", "")
    token = resultado.get("token", "")

    partes = urlsplit(url)
    host = partes.hostname or ""

    if (
        partes.scheme != "https"
        or not (
            host == "flow.cl"
            or host.endswith(".flow.cl")
        )
        or not isinstance(token, str)
        or not 1 <= len(token) <= 250
    ):
        raise FlowAPIError("Enlace de pago inválido")

    separador = "&" if partes.query else "?"

    return {
        "url_pago": (
            f"{url}{separador}"
            f"token={quote(token, safe='')}"
        ),
        "token": token,
        "flow_order": resultado.get("flowOrder")
    }


def consultar_pago_flow(token):
    if not isinstance(token, str) or not 1 <= len(token) <= 250:
        raise ValueError("Token inválido")

    return consultar_api_flow(
        "payment/getStatus",
        {"token": token}
    )


def consultar_pago_por_orden(orden):
    """
    Consulta una orden existente mediante su
    identificador comercial de SocialSale.
    No crea un nuevo cobro.
    """

    if (
        not isinstance(orden, str)
        or not re.fullmatch(
            r"SS-[0-9]+-[a-f0-9]{24}",
            orden
        )
    ):
        raise ValueError(
            "Identificador de orden inválido"
        )

    return consultar_api_flow(
        "payment/getStatusByCommerceId",
        {"commerceId": orden},
        "GET"
    )

