from db import obtener_conexion


try:

    with obtener_conexion() as conexion:

        with conexion.cursor() as cursor:

            cursor.execute(
                """
                SELECT
                    codigo,
                    descripcion,
                    precio,
                    estado
                FROM producto
                ORDER BY id_producto;
                """
            )

            productos = cursor.fetchall()


            print("")
            print("PRODUCTOS EN SOCIALSALE")
            print("=" * 60)


            for producto in productos:

                print(
                    f"Código: {producto['codigo']} | "
                    f"{producto['descripcion']} | "
                    f"${producto['precio']} | "
                    f"{producto['estado']}"
                )


except Exception as error:

    print(
        "ERROR:",
        error
    )