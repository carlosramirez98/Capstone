
import os
import re
import secrets

from decimal import Decimal, InvalidOperation
from urllib.parse import urlsplit

from flask import Blueprint, abort, redirect, request, url_for

from db import obtener_conexion

from flow_pago import (
    FlowAPIError,
    FlowHTTPError,
    crear_pago_flow,
    consultar_pago_flow,
    consultar_pago_por_orden
)


flow_bp = Blueprint("flow", __name__)

TOKEN_CARRITO = re.compile(r"[A-Za-z0-9_-]{43}\Z")
CORREO = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+\Z")


def _base_publica():
    base = os.getenv("PUBLIC_BASE_URL", "").strip().rstrip("/")
    partes = urlsplit(base)

    if (
        partes.scheme != "https"
        or not partes.hostname
        or partes.username
        or partes.password
        or partes.query
        or partes.fragment
        or partes.path not in ("", "/")
    ):
        raise RuntimeError("Configura PUBLIC_BASE_URL con HTTPS")

    return base


def _total_de_detalles(cursor, id_pedido):
    cursor.execute("""
        SELECT
            COUNT(*) AS cantidad,
            COALESCE(SUM(precio_unitario), 0) AS total
        FROM detalle_pedido
        WHERE id_pedido = %s;
    """, (id_pedido,))

    fila = cursor.fetchone()

    return int(fila["cantidad"]), Decimal(str(fila["total"]))


def _aplicar_estado_confirmado(resultado, token=None):
    """
    Solo registra estados obtenidos directamente
    desde payment/getStatus de Flow.
    """

    if not isinstance(resultado, dict):
        raise ValueError("Respuesta Flow inválida")

    orden = str(resultado.get("commerceOrder") or "")
    moneda = resultado.get("currency")

    try:
        monto = Decimal(str(resultado["amount"]))
        estado = int(resultado["status"])
        numero_flow = int(resultado["flowOrder"])
    except (
        KeyError, TypeError, ValueError, InvalidOperation
    ) as error:
        raise ValueError(
            "Confirmación de pago incompleta"
        ) from error

    if (
        not orden
        or moneda != "CLP"
        or estado not in (1, 2, 3, 4)
    ):
        raise ValueError("Estado u orden Flow inválidos")

    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:

            if estado == 2:
                cursor.execute("""
                    SELECT pr.id_producto
                    FROM producto pr
                    JOIN detalle_pedido dp
                        ON dp.id_producto = pr.id_producto
                    JOIN pago_flow f
                        ON f.id_pedido = dp.id_pedido
                    WHERE f.orden_comercio = %s
                    ORDER BY pr.id_producto
                    FOR UPDATE OF pr;
                """, (orden,))
                cursor.fetchall()

            cursor.execute("""
                SELECT
                    f.id_pago_flow,
                    f.id_pedido,
                    f.token_flow,
                    f.flow_order,
                    f.estado,
                    f.monto_clp,
                    p.estado_pago,
                    p.total,
                    p.pago_expirado_en
                FROM pago_flow f
                JOIN pedido p
                    ON p.id_pedido = f.id_pedido
                WHERE f.orden_comercio = %s
                FOR UPDATE OF f, p;
            """, (orden,))

            registro = cursor.fetchone()

            if not registro:
                raise ValueError(
                    "Pago no registrado en SocialSale"
                )

            
            if token and registro["token_flow"] not in (None, token):
                raise ValueError("Token Flow no coincide")


            if (
                registro["flow_order"] is not None
                and int(registro["flow_order"]) != numero_flow
            ):
                raise ValueError("Orden Flow no coincide")

            if monto != Decimal(str(registro["monto_clp"])):
                raise ValueError("Monto Flow no coincide")

            if registro["estado"] == "pagado":
                return "pagado"

            if (
                estado == 2
                and registro["estado"] in ("rechazado", "anulado")
            ):
                raise ValueError(
                    "Pago confirmado sobre una operación cerrada. "
                    "Requiere revisión manual."
                )

            if estado == 2:

                if registro["pago_expirado_en"] is not None:
                    raise ValueError(
                        "Flow confirmó un pago para un pedido "
                        "ya liberado. Requiere revisión y devolución."
                    )

                cantidad, total_detalles = _total_de_detalles(
                    cursor,
                    registro["id_pedido"]
                )

                if (
                    cantidad == 0
                    or total_detalles != monto
                    or Decimal(str(registro["total"])) != monto
                ):
                    raise ValueError(
                        "El contenido del pedido cambió"
                    )

                if registro["estado_pago"] == "pagado":
                    raise ValueError(
                        "El pedido ya figura pagado por otra vía"
                    )

                cursor.execute("""
                    
                    UPDATE pago_flow
                    SET estado = 'pagado',
                        flow_order = %s,
                        token_flow = COALESCE(token_flow, %s),
                        confirmado_en = NOW(),
                        actualizado_en = NOW()
                    WHERE id_pago_flow = %s;

                """, (
    numero_flow,
    token,
    registro["id_pago_flow"]
))

                cursor.execute("""
                    UPDATE pedido
                    SET estado_pago = 'pagado',
                        fecha_pago = NOW()
                    WHERE id_pedido = %s;
                """, (registro["id_pedido"],))

                cursor.execute("""
                    UPDATE producto pr
                    SET estado = 'vendido'
                    FROM detalle_pedido dp
                    WHERE dp.id_pedido = %s
                      AND dp.id_producto = pr.id_producto;
                """, (registro["id_pedido"],))

                return "pagado"

            nuevo_estado = {
                1: "pendiente",
                3: "rechazado",
                4: "anulado"
            }[estado]

            if (
                registro["estado"] in ("rechazado", "anulado")
                and nuevo_estado == "pendiente"
            ):
                return registro["estado"]

            cursor.execute("""
                
UPDATE pago_flow
SET estado = %s,
    flow_order = %s,
    token_flow = COALESCE(token_flow, %s),
    actualizado_en = NOW()
WHERE id_pago_flow = %s;

            """, (
    nuevo_estado,
    numero_flow,
    token,
    registro["id_pago_flow"]
))

            return nuevo_estado


@flow_bp.route(
    "/carrito/<token>/pagar-flow",
    methods=["POST"]
)
def iniciar_pago(token):
    if not TOKEN_CARRITO.fullmatch(token):
        abort(404)

    if os.getenv("FLOW_PAGOS_HABILITADOS", "0") != "1":
        abort(503, "Los pagos aún no están habilitados.")

    try:
        base = _base_publica()
    except RuntimeError:
        abort(503, "La URL pública no está configurada.")

    correo = request.form.get("correo", "").strip().lower()

    if len(correo) > 254 or not CORREO.fullmatch(correo):
        abort(400, "Ingresa un correo válido.")

    orden_nueva = None
    url_existente = None

    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:     
            cursor.execute("""
                SELECT
                    id_pedido,
                    estado_pago,
                    total,
                    pago_expirado_en,
                    plazo_pago_hasta,
                    GREATEST(
                        0,
                        CEIL(
                            EXTRACT(
                                EPOCH FROM (plazo_pago_hasta - NOW())
                            )
                        )
                    )::integer AS segundos_restantes
                FROM pedido
                WHERE token_carrito = %s
                FOR UPDATE;
            """, (token,))

            pedido = cursor.fetchone()


            if not pedido:
                abort(404)

            if pedido["estado_pago"] == "pagado":
                return redirect(
                    url_for("ver_carrito", token=token),
                    code=303
                )

            # Verificar que no hayan pasado los 20 minutos
            if (
                pedido["pago_expirado_en"] is not None
                or pedido["plazo_pago_hasta"] is None
                or pedido["segundos_restantes"] <= 0
            ):
                abort(
                    410,
                    "Tu plazo de 20 minutos terminó. "
                    "Contacta a la vendedora."
                )

            # Calcular el total del pedido
            cantidad, monto = _total_de_detalles(
                cursor,
                pedido["id_pedido"]
            )

            if (
                cantidad == 0
                or monto <= 0
                or monto != Decimal(str(pedido["total"]))
                or monto != monto.to_integral_value()
            ):
                abort(
                    409,
                    "El total del pedido no es válido."
                )

            cursor.execute("""
                SELECT
                    orden_comercio,
                    estado,
                    url_pago
                FROM pago_flow
                WHERE id_pedido = %s
                  AND estado IN ('creando', 'pendiente')
                ORDER BY id_pago_flow DESC
                LIMIT 1
                FOR UPDATE;
            """, (pedido["id_pedido"],))

            actual = cursor.fetchone()

            if actual:
                if (
                    actual["estado"] == "pendiente"
                    and actual["url_pago"]
                ):
                    url_existente = actual["url_pago"]
                else:
                    abort(
                        409,
                        "Ya hay un pago en proceso. "
                        "Contacta a la vendedora."
                    )
            else:
                orden_nueva = (
                    f'SS-{pedido["id_pedido"]}-'
                    f'{secrets.token_hex(12)}'
                )

                cursor.execute("""
                    INSERT INTO pago_flow (
                        id_pedido,
                        orden_comercio,
                        correo_pagador,
                        monto_clp,
                        estado
                    )
                    VALUES (%s, %s, %s, %s, 'creando');
                """, (
                    pedido["id_pedido"],
                    orden_nueva,
                    correo,
                    int(monto)
                ))

    if url_existente:
        return redirect(url_existente, code=303)

    try:
        nuevo = crear_pago_flow(
            orden_nueva,
            int(monto),
            correo,
            f"{base}/flow/confirmacion",
            f"{base}/flow/retorno",
            timeout_segundos=pedido["segundos_restantes"]
            
        )

    
    except FlowHTTPError:
        # No desbloquear la orden automáticamente:
        # debemos comprobar antes si Flow la creó.
        abort(
            503,
            "Flow no pudo confirmar la solicitud. "
            "Verifica la orden antes de reintentar."
        )


    except (FlowAPIError, ValueError):
        abort(
            503,
            "No pudimos confirmar la creación del cobro. "
            "No intentes crear otro pago todavía."
        )

    
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute("""
                UPDATE pago_flow
                SET estado = CASE
                        WHEN estado = 'creando'
                            THEN 'pendiente'
                        ELSE estado
                    END,
                    token_flow = COALESCE(token_flow, %s),
                    url_pago = COALESCE(url_pago, %s),
                    flow_order = COALESCE(flow_order, %s),
                    actualizado_en = NOW()
                WHERE orden_comercio = %s
                  AND estado IN (
                      'creando',
                      'pendiente',
                      'pagado',
                      'rechazado',
                      'anulado'
                  )
                RETURNING estado;
            """, (
                nuevo["token"],
                nuevo["url_pago"],
                nuevo["flow_order"],
                orden_nueva
            ))

            registro = cursor.fetchone()

            if registro is None:
                raise RuntimeError(
                    "No se pudo registrar la orden Flow"
                )

    if registro["estado"] != "pendiente":
        return redirect(
            url_for("ver_carrito", token=token),
            code=303
        )


    return redirect(nuevo["url_pago"], code=303)


@flow_bp.route(
    "/flow/confirmacion",
    methods=["POST"]
)
def confirmar_pago():
    token = request.form.get("token", "")

    if not token or len(token) > 250:
        abort(400)

    try:
        resultado = consultar_pago_flow(token)
        _aplicar_estado_confirmado(resultado, token)

        return "OK", 200

    except Exception as error:
        print(
            "[FLOW confirmación] Error:",
            type(error).__name__
        )
        return "No se pudo verificar el pago", 503


@flow_bp.route(
    "/flow/retorno",
    methods=["GET", "POST"]
)
def retorno_pago():
    token = request.values.get("token", "").strip()

    if not token or len(token) > 250:
        return (
            "No se recibió token de Flow. "
            "Contacta a la vendedora.",
            400
        )

    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute("""
                SELECT p.token_carrito
                FROM pago_flow f
                JOIN pedido p
                    ON p.id_pedido = f.id_pedido
                WHERE f.token_flow = %s
                LIMIT 1;
            """, (token,))

            fila = cursor.fetchone()

    if not fila:
        return "Transacción no encontrada.", 404

    try:
        resultado = consultar_pago_flow(token)
        _aplicar_estado_confirmado(resultado, token)
    except Exception as error:
        print(
            "[FLOW retorno] Verificación pendiente:",
            type(error).__name__
        )

    return redirect(
        url_for(
            "ver_carrito",
            token=fila["token_carrito"]
        ),
        code=303
    )



@flow_bp.route(
    "/carrito/<token>/verificar-flow",
    methods=["POST"]
)
def verificar_pago(token):

    if not TOKEN_CARRITO.fullmatch(token):
        abort(404)

    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute("""
                SELECT
                    f.token_flow,
                    f.orden_comercio
                FROM pago_flow f
                JOIN pedido p
                    ON p.id_pedido = f.id_pedido
                WHERE p.token_carrito = %s
                  AND f.estado IN (
                      'pendiente',
                      'creando'
                  )
                ORDER BY f.id_pago_flow DESC
                LIMIT 1;
            """, (token,))

            fila = cursor.fetchone()

    if fila:
        try:
            if fila["token_flow"]:
                resultado = consultar_pago_flow(
                    fila["token_flow"]
                )

                _aplicar_estado_confirmado(
                    resultado,
                    fila["token_flow"]
                )

            else:
                resultado = consultar_pago_por_orden(
                    fila["orden_comercio"]
                )

                _aplicar_estado_confirmado(
                    resultado
                )

        except Exception as error:
            print(
                "[FLOW conciliación]",
                type(error).__name__
            )

    return redirect(
        url_for("ver_carrito", token=token),
        code=303
    )

