from TikTokLive import TikTokLiveClient
from TikTokLive.events import (
    ConnectEvent,
    CommentEvent,
    DisconnectEvent
)

from TikTokLive.client.errors import UserOfflineError

import asyncio
from datetime import datetime
from threading import Lock

import re
import time
import unicodedata

from db import obtener_conexion
from pedidos import agregar_producto_a_pedido


# ============================================================
# CONFIGURACIÓN
# ============================================================

# Se conserva temporalmente para no romper app.py.
# El capturador ya no dependerá de esta constante.
UNIQUE_ID = "@marditocarlitoo_"

# El cliente de TikTok se creará dinámicamente
# según la transmisión que esté en curso.


# ============================================================
# ESTADO TEMPORAL DEL CLIENTE
#
# Esto NO representa datos del negocio.
# Solamente indica si TikTokLive está conectado.
# ============================================================

lock = Lock()

estado_live = {
    "conectado": False,
    "usuario": None,
    "id_live": None
}


# ============================================================
# NORMALIZAR TEXTO
# ============================================================

def normalizar_texto(texto):

    texto = texto.lower().strip()

    texto = unicodedata.normalize(
        "NFD",
        texto
    )

    texto = "".join(
        caracter
        for caracter in texto
        if unicodedata.category(caracter) != "Mn"
    )

    return texto


# ============================================================
# DETECTAR INTENCIÓN DE COMPRA
# ============================================================

def tiene_intencion_compra(texto):

    patrones = [
        r"\byo\b",
        r"\bquiero\b",
        r"\bmio\b",
        r"\bmia\b",
        r"\bdame\b",
        r"\bme\s+llevo\b",
        r"\bpara\s+mi\b",
        r"\breservo\b",
        r"\breservame\b",
        r"\baparto\b",
        r"\bapartame\b",
        r"\bme\s+quedo\b",
        r"\blo\s+quiero\b",
        r"\bla\s+quiero\b"
    ]


    for patron in patrones:

        if re.search(
            patron,
            texto
        ):

            return True


    return False


# ============================================================
# OBTENER LIVE ACTUAL
# ============================================================


def obtener_live_actual(conexion, id_live, cuenta_tiktok):

    with conexion.cursor() as cursor:

        cursor.execute(
            """
            SELECT
                id_live,
                titulo,
                cuenta_tiktok,
                estado

            FROM live

            WHERE id_live = %s
              AND cuenta_tiktok = %s
              AND estado = 'en_curso'

            FOR UPDATE;
            """,
            (id_live, cuenta_tiktok)
        )

        return cursor.fetchone()



# ============================================================
# BUSCAR PRODUCTO SEGÚN COMENTARIO
# ============================================================

def detectar_producto(
    conexion,
    id_live,
    texto
):

    texto_normalizado = (
        normalizar_texto(
            texto
        )
    )


    codigos = re.findall(
    r"[a-z0-9]+(?:[-_][a-z0-9]+)*",
    texto_normalizado
    )

    if not codigos:
        return None

    for codigo in codigos:

        with conexion.cursor() as cursor:

            cursor.execute(
                """
                SELECT
                    id_producto,
                    codigo,
                    descripcion,
                    precio,
                    estado
                FROM producto
                WHERE
                    id_live = %s
                    AND UPPER(codigo) = %s
                LIMIT 1;
                """,
                (
                    id_live,
                    codigo.upper()
                )
            )


            producto = (
                cursor.fetchone()
            )


        if not producto:
            continue


        # --------------------------------------------
        # CASO:
        # comentario solamente "13"
        # --------------------------------------------

        if (
            texto_normalizado
            ==
            codigo
        ):

            return producto


        # --------------------------------------------
        # CASO:
        # "quiero el 13"
        # "yo 13"
        # "13 mio"
        # --------------------------------------------

        if tiene_intencion_compra(
            texto_normalizado
        ):

            return producto


    return None


# ============================================================
# CREAR O ACTUALIZAR COMPRADOR
# ============================================================

def obtener_o_crear_comprador(
    conexion,
    usuario_id,
    nickname
):

    with conexion.cursor() as cursor:

        cursor.execute(
            """
            INSERT INTO comprador (
                plataforma,
                username,
                nickname
            )

            VALUES (
                'tiktok',
                %s,
                %s
            )

            ON CONFLICT (
                plataforma,
                username
            )

            DO UPDATE SET
                nickname =
                    EXCLUDED.nickname

            RETURNING
                id_comprador;
            """,
            (
                usuario_id,
                nickname
            )
        )


        comprador = (
            cursor.fetchone()
        )


    return comprador[
        "id_comprador"
    ]


# ============================================================
# OBTENER SIGUIENTE ORDEN DE RECEPCIÓN
# ============================================================

def obtener_siguiente_orden(
    conexion,
    id_live
):

    # Bloqueamos el Live mientras calculamos
    # el siguiente orden.
    #
    # Esto evita que dos comentarios obtengan
    # el mismo número al mismo tiempo.

    with conexion.cursor() as cursor:

        cursor.execute(
            """
            SELECT id_live

            FROM live

            WHERE id_live = %s

            FOR UPDATE;
            """,
            (
                id_live,
            )
        )


        cursor.execute(
            """
            SELECT
                COALESCE(
                    MAX(orden_recepcion),
                    0
                ) + 1
                AS siguiente

            FROM mensaje_chat

            WHERE id_live = %s;
            """,
            (
                id_live,
            )
        )


        resultado = (
            cursor.fetchone()
        )


    return resultado[
        "siguiente"
    ]


# ============================================================
# GUARDAR MENSAJE
# ============================================================

def guardar_mensaje(
    conexion,
    id_live,
    id_comprador,
    usuario_id,
    nickname,
    texto,
    orden,
    codigo_detectado,
    intencion_compra
):

    with conexion.cursor() as cursor:

        cursor.execute(
            """
            INSERT INTO mensaje_chat (
                id_live,
                id_comprador,
                plataforma,
                username,
                nickname,
                contenido,
                orden_recepcion,
                codigo_detectado,
                intencion_compra
            )

            VALUES (
                %s,
                %s,
                'tiktok',
                %s,
                %s,
                %s,
                %s,
                %s,
                %s
            )

            RETURNING
                id_mensaje;
            """,
            (
                id_live,
                id_comprador,
                usuario_id,
                nickname,
                texto,
                orden,
                codigo_detectado,
                intencion_compra
            )
        )


        mensaje = (
            cursor.fetchone()
        )


    return mensaje[
        "id_mensaje"
    ]


# ============================================================
# VERIFICAR SI USUARIO YA PARTICIPA
# ============================================================

def usuario_ya_participa(
    conexion,
    id_producto,
    id_comprador
):

    with conexion.cursor() as cursor:

        cursor.execute(
            """
            SELECT 1

            FROM adjudicacion

            WHERE
                id_producto = %s
                AND id_comprador = %s
                AND estado IN (
                    'pendiente',
                    'aceptada'
                )

            LIMIT 1;
            """,
            (
                id_producto,
                id_comprador
            )
        )


        if cursor.fetchone():

            return True


        cursor.execute(
            """
            SELECT 1

            FROM lista_espera

            WHERE
                id_producto = %s
                AND id_comprador = %s
                AND estado = 'esperando'

            LIMIT 1;
            """,
            (
                id_producto,
                id_comprador
            )
        )


        return (
            cursor.fetchone()
            is not None
        )

# ============================================================
# CREAR ADJUDICACIÓN AUTOMÁTICA
# ============================================================

def crear_adjudicacion(
    conexion,
    id_live,
    producto,
    id_comprador,
    id_mensaje
):

    with conexion.cursor() as cursor:

        cursor.execute(
            """
            INSERT INTO adjudicacion (
                id_producto,
                id_comprador,
                id_mensaje,
                tipo,
                estado
            )

            VALUES (
                %s,
                %s,
                %s,
                'automatica',
                'aceptada'
            )

            RETURNING id_adjudicacion;
            """,
            (
                producto["id_producto"],
                id_comprador,
                id_mensaje
            )
        )


        adjudicacion = (
            cursor.fetchone()
        )


        cursor.execute(
            """
            UPDATE producto

            SET estado = 'reservado'

            WHERE id_producto = %s;
            """,
            (
                producto["id_producto"],
            )
        )


    # --------------------------------------------------------
    # CREAR / ACTUALIZAR PEDIDO DE LA COMPRADORA
    # --------------------------------------------------------

    agregar_producto_a_pedido(
        conexion=conexion,
        id_live=id_live,
        id_comprador=id_comprador,
        id_producto=producto["id_producto"],
        precio=producto["precio"]
    )


    return adjudicacion[
        "id_adjudicacion"
    ]

# ============================================================
# AGREGAR A LISTA DE ESPERA
# ============================================================

def agregar_lista_espera(
    conexion,
    producto,
    id_comprador,
    id_mensaje
):

    id_producto = producto[
        "id_producto"
    ]


    with conexion.cursor() as cursor:

        cursor.execute(
            """
            SELECT
                COALESCE(
                    MAX(posicion),
                    0
                ) + 1
                AS siguiente

            FROM lista_espera

            WHERE
                id_producto = %s
                AND estado = 'esperando';
            """,
            (
                id_producto,
            )
        )


        resultado = (
            cursor.fetchone()
        )


        posicion = resultado[
            "siguiente"
        ]


        cursor.execute(
            """
            INSERT INTO lista_espera (
                id_producto,
                id_comprador,
                id_mensaje,
                posicion,
                estado
            )

            VALUES (
                %s,
                %s,
                %s,
                %s,
                'esperando'
            );
            """,
            (
                id_producto,
                id_comprador,
                id_mensaje,
                posicion
            )
        )


    return posicion


# ============================================================
# PROCESAR COMENTARIO REAL
# ============================================================

def procesar_comentario_db(
    usuario_id,
    nickname,
    texto,
    id_live,
    cuenta_tiktok
):

    with obtener_conexion() as conexion:

        # --------------------------------------------
        # LIVE ACTUAL
        # --------------------------------------------

        live = obtener_live_actual(
            conexion,
            id_live,
            cuenta_tiktok
        )


        if not live:

            print(
                "[BD] No existe un Live "
                "en curso para esta cuenta."
            )

            return


        id_live = live[
            "id_live"
        ]


        # --------------------------------------------
        # COMPRADOR
        # --------------------------------------------

        id_comprador = (
            obtener_o_crear_comprador(
                conexion,
                usuario_id,
                nickname
            )
        )


        # --------------------------------------------
        # DETECTAR PRODUCTO
        # --------------------------------------------

        producto = detectar_producto(
            conexion,
            id_live,
            texto
        )


        if producto:

            codigo_detectado = (
                producto[
                    "codigo"
                ]
            )

            intencion_compra = True

        else:

            codigo_detectado = None

            intencion_compra = False


        # --------------------------------------------
        # ORDEN DE LLEGADA
        # --------------------------------------------

        orden = obtener_siguiente_orden(
            conexion,
            id_live
        )


        # --------------------------------------------
        # GUARDAR MENSAJE
        # --------------------------------------------

        id_mensaje = guardar_mensaje(
            conexion,
            id_live,
            id_comprador,
            usuario_id,
            nickname,
            texto,
            orden,
            codigo_detectado,
            intencion_compra
        )


        # Si no representa compra,
        # guardamos solamente el mensaje.

        if not producto:

            conexion.commit()

            return


        # --------------------------------------------
        # BLOQUEAR PRODUCTO
        # --------------------------------------------

        with conexion.cursor() as cursor:

            cursor.execute(
                """
                SELECT
                    id_producto,
                    codigo,
                    descripcion,
                    precio,
                    estado

                FROM producto

                WHERE id_producto = %s

                FOR UPDATE;
                """,
                (
                    producto[
                        "id_producto"
                    ],
                )
            )


            producto = (
                cursor.fetchone()
            )


        # --------------------------------------------
        # EVITAR USUARIO DUPLICADO
        # --------------------------------------------

        if usuario_ya_participa(
            conexion,
            producto[
                "id_producto"
            ],
            id_comprador
        ):

            conexion.commit()

            print(
                f"[IGNORADO] "
                f"@{usuario_id} ya estaba "
                f"participando por el "
                f"código {producto['codigo']}."
            )

            return


        # --------------------------------------------
        # PRODUCTO DISPONIBLE
        # --------------------------------------------

        if producto[
            "estado"
        ] in (
            "disponible",
            "liberado"
        ):

            crear_adjudicacion(
                conexion,
                id_live,
                producto,
                id_comprador,
                id_mensaje
            )


            conexion.commit()


            print("")
            print("=" * 60)
            print("NUEVA ADJUDICACIÓN")
            print("=" * 60)

            print(
                f"Usuario: @{usuario_id}"
            )

            print(
                f"Código: {producto['codigo']}"
            )

            print(
                f"Producto: "
                f"{producto['descripcion']}"
            )

            print(
                f"Precio: "
                f"${producto['precio']:,}"
            )

            print(
                f"Orden de llegada: "
                f"{orden}"
            )

            print("=" * 60)
            print("")


            return


        # --------------------------------------------
        # PRODUCTO PENDIENTE O RESERVADO
        #
        # La persona pasa a lista de espera.
        # --------------------------------------------

        if producto[
            "estado"
        ] in (
            "pendiente",
            "reservado"
        ):

            posicion = agregar_lista_espera(
                conexion,
                producto,
                id_comprador,
                id_mensaje
            )


            conexion.commit()


            print(
                f"[LISTA DE ESPERA] "
                f"@{usuario_id} → "
                f"Código {producto['codigo']} → "
                f"Posición {posicion}"
            )


            return


        # --------------------------------------------
        # PRODUCTO VENDIDO
        # --------------------------------------------

        conexion.commit()


        print(
            f"[INFO] El producto "
            f"{producto['codigo']} "
            f"no está disponible."
        )


# ============================================================
# CAPTURA DINÁMICA SEGÚN EL LIVE EN CURSO
# ============================================================

def consultar_live_para_captura():

    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:

            cursor.execute(
                """
                SELECT id_live, cuenta_tiktok
                FROM live
                WHERE estado = 'en_curso'
                ORDER BY id_live DESC
                LIMIT 2;
                """
            )

            lives = cursor.fetchall()

    if len(lives) > 1:
        raise RuntimeError(
            "Hay más de un Live en curso. "
            "Finaliza el Live anterior antes de continuar."
        )

    return lives[0] if lives else None


# ============================================================
# CREAR CLIENTE PARA LA CUENTA SELECCIONADA
# ============================================================

def crear_cliente_live(cuenta_tiktok, id_live):

    nuevo_cliente = TikTokLiveClient(
        unique_id=cuenta_tiktok
    )

    @nuevo_cliente.on(ConnectEvent)
    async def al_conectar(event: ConnectEvent):

        with lock:
            if estado_live["id_live"] != id_live:
                return

            estado_live["conectado"] = True

        print(
            f"[OK] Conectado a {cuenta_tiktok} "
            f"(Live {id_live})"
        )

    @nuevo_cliente.on(CommentEvent)
    async def al_comentar(event: CommentEvent):

        with lock:
            if estado_live["id_live"] != id_live:
                return

        usuario_id = event.user.unique_id
        nickname = event.user.nickname
        texto = event.comment.strip()

        print(
            f"[{cuenta_tiktok}] "
            f"@{usuario_id}: {texto}"
        )

        try:
            procesar_comentario_db(
                usuario_id,
                nickname,
                texto,
                id_live,
                cuenta_tiktok
            )

        except Exception as error:
            print(f"[ERROR BD] {error}")

    @nuevo_cliente.on(DisconnectEvent)
    async def al_desconectar(event: DisconnectEvent):

        with lock:
            if estado_live["id_live"] == id_live:
                estado_live["conectado"] = False

        print(
            f"[INFO] Desconectado de {cuenta_tiktok}"
        )

    return nuevo_cliente


# ============================================================
# CERRAR CONEXIÓN ANTERIOR
# ============================================================

async def cerrar_cliente_live(cliente, tarea):

    if cliente is None:
        return

    try:
        await cliente.disconnect()

    except Exception as error:
        print(
            f"[INFO] Al desconectar cliente: {error}"
        )

    if tarea is not None:
        await asyncio.gather(
            tarea,
            return_exceptions=True
        )

    try:
        # Cerrar la sesión HTTP del cliente descartado.
        # En TikTokLive 7.0.1 evitamos client.close()
        # dentro de un event loop activo.
        await cliente.web.close()

    except Exception as error:
        print(
            f"[INFO] Al cerrar cliente web: {error}"
        )


# ============================================================
# SUPERVISAR CUENTA SELECCIONADA
# ============================================================

async def supervisar_captura():

    objetivo_actual = None
    cliente = None
    tarea = None
    siguiente_intento = 0.0

    while True:

        try:
            live = await asyncio.to_thread(
                consultar_live_para_captura
            )

        except Exception as error:

            print(
                f"[ERROR] Consultando Live activo: {error}"
            )

            await asyncio.sleep(3)
            continue

        objetivo = (
            (
                live["id_live"],
                live["cuenta_tiktok"]
            )
            if live else None
        )

        # Detectar cambio de transmisión o cuenta
        if objetivo != objetivo_actual:

            # Invalidar eventos de la conexión anterior
            with lock:

                estado_live["conectado"] = False

                estado_live["id_live"] = (
                    objetivo[0] if objetivo else None
                )

                estado_live["usuario"] = (
                    objetivo[1] if objetivo else None
                )

            await cerrar_cliente_live(cliente, tarea)

            cliente = None
            tarea = None
            objetivo_actual = objetivo
            siguiente_intento = 0.0

            if objetivo:
                print(
                    f"[INFO] Cuenta elegida: {objetivo[1]}"
                )

        # Detectar conexiones que finalizaron
        if tarea is not None and tarea.done():

            try:
                tarea.result()

            except Exception as error:
                print(
                    f"[INFO] Conexión TikTok "
                    f"finalizada: {error}"
                )

            await cerrar_cliente_live(cliente, tarea)

            cliente = None
            tarea = None

            with lock:
                estado_live["conectado"] = False

        # Conectar cuando exista un Live en curso
        if (
            objetivo_actual
            and tarea is None
            and time.monotonic() >= siguiente_intento
        ):

            id_live, cuenta_tiktok = objetivo_actual

            cliente = crear_cliente_live(
                cuenta_tiktok,
                id_live
            )

            siguiente_intento = (
                time.monotonic() + 10
            )

            try:
                tarea = await cliente.start()

            except UserOfflineError:
                print(
                    f"[INFO] {cuenta_tiktok} "
                    f"no está transmitiendo."
                )

            except Exception as error:
                print(
                    f"[ERROR] Conexión con "
                    f"{cuenta_tiktok}: {error}"
                )

            if tarea is None:

                await cerrar_cliente_live(
                    cliente,
                    None
                )

                cliente = None

        await asyncio.sleep(2)


# ============================================================
# INICIAR CAPTURA
# ============================================================

def iniciar_captura():

    asyncio.run(supervisar_captura())


if __name__ == "__main__":

    iniciar_captura()
