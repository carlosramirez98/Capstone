from flask import (
    Flask,
    render_template,
    jsonify,
    request,
    url_for,
    redirect,
    abort,
    session
)

import secrets
import re
import os

from threading import Thread

from psycopg.errors import (
    UniqueViolation,
    ForeignKeyViolation
)

from db import obtener_conexion
from flow_integracion import flow_bp

from pedidos import (
    agregar_producto_a_pedido,
    quitar_producto_de_pedido
)


from consumir import (
    iniciar_captura,
    estado_live,
    lock
)

from werkzeug.security import check_password_hash
from werkzeug.security import generate_password_hash
from plazos_pago import ejecutar_bucle_vencimientos

app = Flask(__name__)

app.config["SECRET_KEY"] = os.getenv("FLASK_SECRET_KEY")

if not app.config["SECRET_KEY"]:
    raise RuntimeError(
        "Falta configurar FLASK_SECRET_KEY en el archivo .env"
    )

app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

# Registrar las rutas de pago Flow
app.register_blueprint(flow_bp)


# ============================================================
# PROTECCIÓN DE RUTAS Y VALIDACIÓN DE USUARIOS
# ============================================================

@app.before_request
def proteger_rutas():

    rutas_publicas = {
        "static",
        "iniciar_sesion",
        "registrar_usuario",
        "ver_carrito",
        "pagar_desde_carrito",
        "flow.iniciar_pago",
        "flow.confirmar_pago",
        "flow.retorno_pago",
        "flow.verificar_pago"
    }


    if request.endpoint is None:
        return

    if request.endpoint in rutas_publicas:
        return

    id_usuario = session.get("id_usuario")

    # 1. Verificar que exista una sesión
    if not id_usuario:

        if request.path.startswith("/api/"):
            return jsonify({
                "error": "Debes iniciar sesión para acceder."
            }), 401

        return redirect(url_for("iniciar_sesion"))

    # 2. Verificar el usuario directamente en Neon
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:

            cursor.execute(
                """
                SELECT
                    id_usuario,
                    nombre,
                    rol,
                    activo
                FROM usuario
                WHERE id_usuario = %s
                LIMIT 1;
                """,
                (id_usuario,)
            )

            usuario = cursor.fetchone()

    # 3. Rechazar usuarios eliminados, inactivos
    #    o sin un rol válido
    if (
        not usuario
        or not usuario["activo"]
        or usuario["rol"] not in ("vendedor", "administrador")
    ):

        session.clear()

        if request.path.startswith("/api/"):
            return jsonify({
                "error": "Tu sesión ya no está autorizada."
            }), 401

        return redirect(url_for("iniciar_sesion"))

    # 4. Actualizar los datos si cambiaron en Neon
    if session.get("rol") != usuario["rol"]:
        session["rol"] = usuario["rol"]

    if session.get("nombre") != usuario["nombre"]:
        session["nombre"] = usuario["nombre"]

# ============================================================
# LIVE ACTIVO
# ============================================================


# ============================================================
# OBTENER LIVE ACTIVO O EN PREPARACIÓN
# ============================================================

def obtener_live_activo(conexion):

    with conexion.cursor() as cursor:

        cursor.execute(
            """
            SELECT
                id_live,
                titulo,
                estado,
                cuenta_tiktok

            FROM live

            WHERE estado IN (
                'en_curso',
                'preparacion'
            )

            ORDER BY
                CASE
                    WHEN estado = 'en_curso' THEN 0
                    ELSE 1
                END,

                COALESCE(
                    fecha_inicio,
                    fecha_creacion
                ) DESC

            LIMIT 1;
            """
        )

        return cursor.fetchone()

# ============================================================
# PÁGINA
# ============================================================


@app.route("/")
def inicio():

    if not session.get("id_usuario"):
        return redirect(url_for("iniciar_sesion"))

    if "csrf_logout" not in session:
        session["csrf_logout"] = secrets.token_urlsafe(32)

    if "csrf_configuracion" not in session:
        session["csrf_configuracion"] = secrets.token_urlsafe(32)

    # La cuenta de TikTok pertenece a la transmisión, no a la sesión.
    with obtener_conexion() as conexion:
        live = obtener_live_activo(conexion)

    return render_template(
        "index.html",
        usuario_tiktok=(
            live["cuenta_tiktok"] if live else "Sin seleccionar"
        ),
        csrf_logout=session["csrf_logout"],
        csrf_configuracion=session["csrf_configuracion"]
    )



# ============================================================
# CERRAR SESIÓN
# ============================================================

@app.route("/logout", methods=["POST"])
def cerrar_sesion():

    if not session.get("id_usuario"):
        return redirect(url_for("iniciar_sesion"))

    token_guardado = session.get("csrf_logout")
    token_recibido = request.form.get("csrf_token", "")

    if not token_guardado or not secrets.compare_digest(
        token_guardado, token_recibido
    ):
        return "Solicitud inválida.", 400

    session.clear()

    return redirect(url_for("iniciar_sesion"))


# ============================================================
# INICIO DE SESIÓN
# ============================================================

@app.route("/login", methods=["GET", "POST"])
def iniciar_sesion():

    if session.get("id_usuario"):
        return redirect(url_for("inicio"))

    error = None

    if request.method == "POST":

        csrf_guardado = session.get("csrf_login")
        csrf_recibido = request.form.get("csrf_token", "")

        if not csrf_guardado or not secrets.compare_digest(
            csrf_guardado, csrf_recibido
        ):
            return "Formulario inválido. Recarga la página.", 400

        correo = request.form.get("correo", "").strip().lower()
        password = request.form.get("password", "")

        if not correo or not password:
            error = "Completa todos los campos."

        else:
            with obtener_conexion() as conexion:
                with conexion.cursor() as cursor:
                    cursor.execute(
                        """
                        SELECT
                            id_usuario,
                            nombre,
                            correo,
                            password_hash,
                            rol,
                            activo
                        FROM usuario
                        WHERE LOWER(correo) = %s
                        LIMIT 1;
                        """,
                        (correo,)
                    )

                    usuario = cursor.fetchone()

            if (
                usuario
                and usuario["activo"]
                and check_password_hash(
                    usuario["password_hash"], password
                )
            ):
                session.clear()

                session["id_usuario"] = usuario["id_usuario"]
                session["nombre"] = usuario["nombre"]
                session["rol"] = usuario["rol"]

                return redirect(url_for("inicio"))

            error = "Correo o contraseña incorrectos."

    token = session.get("csrf_login")

    if not token:
        token = secrets.token_urlsafe(32)
        session["csrf_login"] = token

    return render_template(
        "login.html",
        error=error,
        csrf_token=token
    )


# ============================================================
# REGISTRO DE USUARIOS
# ============================================================

@app.route("/registro", methods=["GET", "POST"])
def registrar_usuario():

    if session.get("id_usuario"):
        return redirect(url_for("inicio"))

    error = None
    exito = None

    if "csrf_registro" not in session:
        session["csrf_registro"] = secrets.token_urlsafe(32)

    if request.method == "POST":

        token = request.form.get("csrf_token", "")

        if not secrets.compare_digest(
            session["csrf_registro"], token
        ):
            return "Formulario inválido.", 400

        nombre = request.form.get("nombre", "").strip()
        correo = request.form.get("correo", "").strip().lower()
        password = request.form.get("password", "")
        confirmar = request.form.get("confirmar_password", "")

        if not nombre or not correo or not password:
            error = "Completa todos los campos."

        elif len(nombre) > 100 or len(correo) > 150:
            error = "El nombre o correo supera el límite permitido."

        elif not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", correo):
            error = "Ingresa un correo válido."

        elif len(password) < 12:
            error = "La contraseña debe tener al menos 12 caracteres."

        elif password != confirmar:
            error = "Las contraseñas no coinciden."

        else:

            try:
                password_hash = generate_password_hash(password)

                with obtener_conexion() as conexion:
                    with conexion.cursor() as cursor:

                        cursor.execute(
                            """
                            SELECT id_usuario
                            FROM usuario
                            WHERE LOWER(correo) = %s
                            LIMIT 1;
                            """,
                            (correo,)
                        )

                        existente = cursor.fetchone()

                        if existente:
                            error = "Este correo ya está registrado."

                        else:
                            cursor.execute(
                                """
                                INSERT INTO usuario (
                                    nombre,
                                    correo,
                                    password_hash,
                                    rol,
                                    activo
                                )
                                VALUES (%s, %s, %s, %s, %s);
                                """,
                                (
                                    nombre,
                                    correo,
                                    password_hash,
                                    "vendedor",
                                    True
                                )
                            )

                if not error:
                    exito = (
                        "Cuenta registrada correctamente. "
                    )

            except UniqueViolation:
                error = "Este correo ya está registrado."

    return render_template(
        "registro.html",
        error=error,
        exito=exito,
        csrf_token=session["csrf_registro"]
    )


# ============================================================
# CONFIGURACIÓN DE LA CUENTA
# ============================================================

@app.route("/api/configuracion", methods=["GET", "POST"])
def api_configuracion():
    id_usuario = session["id_usuario"]

    # Consultar los datos de la cuenta actual
    if request.method == "GET":
        with obtener_conexion() as conexion:
            with conexion.cursor() as cursor:
                cursor.execute("""
                    SELECT nombre, correo, rol
                    FROM usuario
                    WHERE id_usuario = %s
                    LIMIT 1
                """, (id_usuario,))

                cuenta = cursor.fetchone()

        if not cuenta:
            return jsonify({
                "error": "Usuario no encontrado."
            }), 404

        return jsonify(cuenta)

    # Protección contra solicitudes externas
    token_guardado = session.get("csrf_configuracion", "")
    token_recibido = request.headers.get("X-CSRF-Token", "")

    if not token_guardado or not secrets.compare_digest(
        token_guardado, token_recibido
    ):
        return jsonify({
            "error": "Formulario inválido. Recarga la página."
        }), 403

    datos = request.get_json(silent=True)

    if not isinstance(datos, dict):
        return jsonify({
            "error": "Solicitud inválida."
        }), 400

    accion = datos.get("accion")

    # --------------------------------------------------------
    # CAMBIAR NOMBRE
    # --------------------------------------------------------

    if accion == "nombre":
        nombre = datos.get("nombre")

        if not isinstance(nombre, str):
            return jsonify({
                "error": "Ingresa un nombre válido."
            }), 400

        nombre = re.sub(r"\s+", " ", nombre).strip()

        if not 2 <= len(nombre) <= 100:
            return jsonify({
                "error": "El nombre debe tener entre 2 y 100 caracteres."
            }), 400

        with obtener_conexion() as conexion:
            with conexion.cursor() as cursor:
                cursor.execute("""
                    UPDATE usuario
                    SET nombre = %s
                    WHERE id_usuario = %s
                    RETURNING nombre
                """, (nombre, id_usuario))

                actualizado = cursor.fetchone()

        if not actualizado:
            return jsonify({
                "error": "Usuario no encontrado."
            }), 404

        # Reflejar el nombre nuevo en la sesión
        session["nombre"] = actualizado["nombre"]

        return jsonify({
            "mensaje": "Nombre actualizado correctamente.",
            "nombre": actualizado["nombre"]
        })

    # --------------------------------------------------------
    # CAMBIAR CONTRASEÑA
    # --------------------------------------------------------

    if accion == "contrasena":
        actual = datos.get("actual")
        nueva = datos.get("nueva")
        confirmar = datos.get("confirmar")

        if not all(
            isinstance(valor, str)
            for valor in (actual, nueva, confirmar)
        ):
            return jsonify({
                "error": "Completa los campos de contraseña."
            }), 400

        if not actual or not nueva or not confirmar:
            return jsonify({
                "error": "Completa los campos de contraseña."
            }), 400

        if not 12 <= len(nueva) <= 128:
            return jsonify({
                "error": "La nueva contraseña debe tener entre 12 y 128 caracteres."
            }), 400

        if nueva != confirmar:
            return jsonify({
                "error": "Las contraseñas nuevas no coinciden."
            }), 400

        with obtener_conexion() as conexion:
            with conexion.cursor() as cursor:
                cursor.execute("""
                    SELECT password_hash
                    FROM usuario
                    WHERE id_usuario = %s
                    FOR UPDATE
                """, (id_usuario,))

                cuenta = cursor.fetchone()

                if not cuenta or not check_password_hash(
                    cuenta["password_hash"], actual
                ):
                    return jsonify({
                        "error": "La contraseña actual es incorrecta."
                    }), 400

                if check_password_hash(
                    cuenta["password_hash"], nueva
                ):
                    return jsonify({
                        "error": "La nueva contraseña debe ser diferente a la actual."
                    }), 400

                nuevo_hash = generate_password_hash(nueva)

                cursor.execute("""
                    UPDATE usuario
                    SET password_hash = %s
                    WHERE id_usuario = %s
                """, (nuevo_hash, id_usuario))

        return jsonify({
            "mensaje": "Contraseña actualizada correctamente."
        })

    return jsonify({
        "error": "Operación de configuración no válida."
    }), 400


# ============================================================
# ADMINISTRACIÓN - LISTAR USUARIOS
# ============================================================

@app.route("/api/usuarios", methods=["GET"])
def listar_usuarios():

    # Solo los administradores pueden consultar usuarios
    if session.get("rol") != "administrador":
        return jsonify({
            "error": "No tienes permisos para acceder."
        }), 403

    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:

            cursor.execute("""
                SELECT
                    id_usuario,
                    nombre,
                    correo,
                    rol,
                    activo,
                    fecha_creacion
                FROM usuario
                ORDER BY fecha_creacion DESC;
            """)

            usuarios = cursor.fetchall()

    return jsonify(usuarios)

# ============================================================
# ESTADO
# ============================================================

@app.route(
    "/api/estado",
    methods=["GET"]
)
def obtener_estado():

    conectado = False


    with lock:
        conectado = bool(estado_live["conectado"])
        usuario_captura = estado_live.get("usuario")
        id_live_captura = estado_live.get("id_live")

    total_comentarios = 0
    total_adjudicaciones = 0
    live = None

    try:

        with obtener_conexion() as conexion:

            live = obtener_live_activo(
                conexion
            )


            if live:

                id_live = live[
                    "id_live"
                ]


                with conexion.cursor() as cursor:

                    cursor.execute(
                        """
                        SELECT COUNT(*) AS total
                        FROM mensaje_chat
                        WHERE id_live = %s;
                        """,
                        (
                            id_live,
                        )
                    )


                    total_comentarios = (
                        cursor.fetchone()[
                            "total"
                        ]
                    )


                    cursor.execute(
                        """
                        SELECT
                            COUNT(*) AS total

                        FROM adjudicacion a

                        JOIN producto p
                            ON p.id_producto =
                               a.id_producto

                        WHERE p.id_live = %s;
                        """,
                        (
                            id_live,
                        )
                    )


                    total_adjudicaciones = (
                        cursor.fetchone()[
                            "total"
                        ]
                    )


    except Exception as error:

        print(
            "[ERROR estado]",
            error
        )


    # Una conexión antigua no debe figurar como la del Live actual.
    conectado = bool(
        conectado
        and live
        and live["estado"] == "en_curso"
        and live["id_live"] == id_live_captura
        and live["cuenta_tiktok"] == usuario_captura
    )

    return jsonify({

        "conectado":
            conectado,

        "usuario":
            usuario_captura,

        "total_comentarios":
            total_comentarios,

        "total_adjudicaciones":
            total_adjudicaciones
    })


# ============================================================
# COMENTARIOS DESDE POSTGRESQL
# ============================================================

@app.route(
    "/api/comentarios",
    methods=["GET"]
)
def obtener_comentarios():

    try:

        with obtener_conexion() as conexion:

            live = obtener_live_activo(
                conexion
            )


            if not live:

                # No hay Live activo: indicar al navegador que
                # debe mostrar el chat vacío. No borrar el historial.
                respuesta = jsonify([])
                respuesta.headers["X-SocialSale-Live"] = "none"
                respuesta.headers["Cache-Control"] = "no-store"
                return respuesta


            with conexion.cursor() as cursor:

                cursor.execute(
                    """
                    SELECT *

                    FROM (
                        SELECT
                            id_mensaje AS id,
                            username AS usuario,
                            nickname,
                            contenido AS texto,

                            TO_CHAR(
                                fecha_hora,
                                'HH24:MI:SS'
                            ) AS hora,

                            orden_recepcion

                        FROM mensaje_chat

                        WHERE id_live = %s

                        ORDER BY
                            orden_recepcion DESC

                        LIMIT 300
                    ) comentarios

                    ORDER BY
                        orden_recepcion ASC;
                    """,
                    (
                        live[
                            "id_live"
                        ],
                    )
                )


                datos = (
                    cursor.fetchall()
                )


        # La respuesta mantiene su formato de lista para no
        # romper la interfaz existente. La cabecera identifica
        # el Live (y su estado) al que pertenecen los mensajes.
        respuesta = jsonify(datos)
        respuesta.headers["X-SocialSale-Live"] = (
            f"{live['id_live']}:{live['estado']}"
        )
        respuesta.headers["Cache-Control"] = "no-store"
        return respuesta


    except Exception as error:

        print(
            "[ERROR comentarios]",
            error
        )

        return jsonify([])


# ============================================================
# PRODUCTOS
# ============================================================

@app.route(
    "/api/productos",
    methods=["GET"]
)
def obtener_productos():

    try:

        with obtener_conexion() as conexion:

            live = obtener_live_activo(
                conexion
            )


            if not live:

                return jsonify([])


            with conexion.cursor() as cursor:

                cursor.execute(
                    """
                    SELECT
                        id_producto,
                        codigo,
                        descripcion,
                        precio,
                        estado,
                        imagen_url

                    FROM producto

                    WHERE id_live = %s

                    ORDER BY id_producto;
                    """,
                    (
                        live[
                            "id_live"
                        ],
                    )
                )


                productos_db = (
                    cursor.fetchall()
                )


                resultado = []


                for producto in productos_db:

                    id_producto = (
                        producto[
                            "id_producto"
                        ]
                    )


                    # ========================================
                    # CANDIDATO PENDIENTE
                    # ========================================

                    cursor.execute(
                        """
                        SELECT
                            c.username AS usuario,
                            c.nickname,

                            a.id_mensaje
                                AS comentario_id,

                            TO_CHAR(
                                a.fecha_hora,
                                'HH24:MI:SS'
                            ) AS hora

                        FROM adjudicacion a

                        JOIN comprador c
                            ON c.id_comprador =
                               a.id_comprador

                        WHERE
                            a.id_producto = %s
                            AND
                            a.estado = 'pendiente'

                        ORDER BY
                            a.id_adjudicacion DESC

                        LIMIT 1;
                        """,
                        (
                            id_producto,
                        )
                    )


                    candidato = (
                        cursor.fetchone()
                    )


                    # ========================================
                    # COMPRADOR ACEPTADO
                    # ========================================

                    cursor.execute(
                        """
                        SELECT
                            c.username,
                            c.nickname

                        FROM adjudicacion a

                        JOIN comprador c
                            ON c.id_comprador =
                               a.id_comprador

                        WHERE
                            a.id_producto = %s
                            AND
                            a.estado = 'aceptada'

                        ORDER BY
                            a.id_adjudicacion DESC

                        LIMIT 1;
                        """,
                        (
                            id_producto,
                        )
                    )


                    comprador = (
                        cursor.fetchone()
                    )


                    # ========================================
                    # LISTA DE ESPERA
                    # ========================================

                    cursor.execute(
                        """
                        SELECT
                            c.username AS usuario,
                            c.nickname,
                            le.posicion,

                            le.id_mensaje
                                AS comentario_id,

                            TO_CHAR(
                                le.fecha_hora,
                                'HH24:MI:SS'
                            ) AS hora

                        FROM lista_espera le

                        JOIN comprador c
                            ON c.id_comprador =
                               le.id_comprador

                        WHERE
                            le.id_producto = %s
                            AND
                            le.estado = 'esperando'

                        ORDER BY
                            le.posicion ASC;
                        """,
                        (
                            id_producto,
                        )
                    )


                    espera = (
                        cursor.fetchall()
                    )


                    resultado.append({

                        "id_producto":
                            id_producto,

                        "codigo":
                            producto[
                                "codigo"
                            ],

                        "descripcion":
                            producto[
                                "descripcion"
                            ],

                        "precio":
                            producto[
                                "precio"
                            ],

                        "estado":
                            producto[
                                "estado"
                            ],

                        "imagen_url":
                            producto[
                                "imagen_url"
                            ],

                        "candidato_actual":
                            candidato,

                        "comprador":
                            comprador[
                                "username"
                            ]
                            if comprador
                            else None,

                        "nickname":
                            comprador[
                                "nickname"
                            ]
                            if comprador
                            else None,

                        "lista_espera":
                            espera
                    })


        return jsonify(
            resultado
        )


    except Exception as error:

        print(
            "[ERROR productos]",
            error
        )

        return jsonify({
            "error":
                "No se pudieron "
                "cargar los productos."
        }), 500


# ============================================================
# CREAR PRODUCTO
# ============================================================

@app.route(
    "/api/productos",
    methods=["POST"]
)
def crear_producto():

    datos = request.get_json(
        silent=True
    ) or {}


    codigo = str(
        datos.get(
            "codigo",
            ""
        )
    ).strip().upper()


    descripcion = str(
        datos.get(
            "descripcion",
            ""
        )
    ).strip()


    precio = datos.get(
        "precio"
    )


    if not codigo:

        return jsonify({
            "error":
                "Debes ingresar un código."
        }), 400


    if not re.fullmatch(r"[A-Z0-9_-]+", codigo):

        return jsonify({
        "error":
            "El código solo puede contener "
            "letras, números, guiones y guiones bajos."
    }), 400


    if (
        precio is None
        or
        str(precio).strip() == ""
    ):

        precio = 5000


    try:

        precio = int(precio)

    except (
        ValueError,
        TypeError
    ):

        return jsonify({
            "error":
                "Precio inválido."
        }), 400


    if precio <= 0:

        return jsonify({
            "error":
                "El precio debe ser "
                "mayor a cero."
        }), 400


    try:

        with obtener_conexion() as conexion:

            live = obtener_live_activo(
                conexion
            )


            if not live:

                return jsonify({
                    "error":
                        "No existe un Live "
                        "activo."
                }), 400


            with conexion.cursor() as cursor:

                cursor.execute(
                    """
                    INSERT INTO producto (
                        id_live,
                        codigo,
                        descripcion,
                        precio,
                        estado
                    )

                    VALUES (
                        %s,
                        %s,
                        %s,
                        %s,
                        'disponible'
                    )

                    RETURNING
                        id_producto,
                        codigo,
                        descripcion,
                        precio,
                        estado;
                    """,
                    (
                        live[
                            "id_live"
                        ],

                        codigo,

                        descripcion
                        if descripcion
                        else None,

                        precio
                    )
                )


                producto = (
                    cursor.fetchone()
                )


            conexion.commit()


        return jsonify({

            "mensaje":
                "Producto agregado "
                "correctamente.",

            "producto":
                producto

        }), 201


    except UniqueViolation:

        return jsonify({
            "error":
                "Ese código ya existe "
                "en este Live."
        }), 400


    except Exception as error:

        print(
            "[ERROR crear producto]",
            error
        )

        return jsonify({
            "error":
                "No se pudo crear "
                "el producto."
        }), 500


# ============================================================
# EDITAR PRODUCTO
# ============================================================

@app.route(
    "/api/productos/<codigo>",
    methods=["PUT"]
)
def editar_producto(codigo):

    datos = request.get_json(
        silent=True
    ) or {}


    try:

        with obtener_conexion() as conexion:

            live = obtener_live_activo(
                conexion
            )


            if not live:

                return jsonify({
                    "error":
                        "No existe un Live activo."
                }), 400


            with conexion.cursor() as cursor:

                cursor.execute(
                    """
                    SELECT
                        id_producto,
                        codigo,
                        descripcion,
                        precio,
                        estado

                    FROM producto

                    WHERE
                        id_live = %s
                        AND codigo = %s

                    LIMIT 1;
                    """,
                    (
                        live[
                            "id_live"
                        ],

                        codigo
                    )
                )


                producto = (
                    cursor.fetchone()
                )


                if not producto:

                    return jsonify({
                        "error":
                            "Producto no encontrado."
                    }), 404


                if (
                    producto[
                        "estado"
                    ]
                    !=
                    "disponible"
                ):

                    return jsonify({
                        "error":
                            "Solo puedes editar "
                            "productos disponibles."
                    }), 400


                nuevo_codigo = str(
                    datos.get(
                        "codigo",
                        codigo
                    )
                ).strip().upper()


                descripcion = str(
                    datos.get(
                        "descripcion",
                        producto[
                            "descripcion"
                        ]
                        or ""
                    )
                ).strip()


                precio = datos.get(
                    "precio",
                    producto[
                        "precio"
                    ]
                )


                if not nuevo_codigo:

                    return jsonify({
                        "error":
                            "El código es obligatorio."
                    }), 400


                if not re.fullmatch(r"[A-Z0-9_-]+", nuevo_codigo):

                    return jsonify({
                        "error":
                            "El código solo puede contener "
                            "letras, números, guiones y guiones bajos."
                    }), 400


                if (
                    precio is None
                    or
                    str(precio).strip() == ""
                ):

                    precio = 5000


                try:

                    precio = int(
                        precio
                    )

                except (
                    ValueError,
                    TypeError
                ):

                    return jsonify({
                        "error":
                            "Precio inválido."
                    }), 400


                if precio <= 0:

                    return jsonify({
                        "error":
                            "Precio inválido."
                    }), 400


                cursor.execute(
                    """
                    UPDATE producto

                    SET
                        codigo = %s,
                        descripcion = %s,
                        precio = %s

                    WHERE id_producto = %s;
                    """,
                    (
                        nuevo_codigo,

                        descripcion
                        if descripcion
                        else None,

                        precio,

                        producto[
                            "id_producto"
                        ]
                    )
                )


            conexion.commit()


        return jsonify({
            "mensaje":
                "Producto actualizado "
                "correctamente."
        })


    except UniqueViolation:

        return jsonify({
            "error":
                "Ese código ya existe."
        }), 400


    except Exception as error:

        print(
            "[ERROR editar]",
            error
        )

        return jsonify({
            "error":
                "No se pudo actualizar."
        }), 500


# ============================================================
# ELIMINAR PRODUCTO
# ============================================================

@app.route(
    "/api/productos/<codigo>",
    methods=["DELETE"]
)
def eliminar_producto(codigo):

    try:

        with obtener_conexion() as conexion:

            live = obtener_live_activo(
                conexion
            )


            if not live:

                return jsonify({
                    "error":
                        "No existe Live activo."
                }), 400


            with conexion.cursor() as cursor:

                cursor.execute(
                    """
                    SELECT
                        id_producto,
                        estado

                    FROM producto

                    WHERE
                        id_live = %s
                        AND codigo = %s

                    LIMIT 1;
                    """,
                    (
                        live[
                            "id_live"
                        ],

                        codigo
                    )
                )


                producto = (
                    cursor.fetchone()
                )


                if not producto:

                    return jsonify({
                        "error":
                            "Producto no encontrado."
                    }), 404


                if (
                    producto[
                        "estado"
                    ]
                    !=
                    "disponible"
                ):

                    return jsonify({
                        "error":
                            "No puedes eliminar "
                            "un producto con una "
                            "adjudicación activa."
                    }), 400


                cursor.execute(
                    """
                    DELETE FROM producto
                    WHERE id_producto = %s;
                    """,
                    (
                        producto[
                            "id_producto"
                        ],
                    )
                )


            conexion.commit()


        return jsonify({
            "mensaje":
                "Producto eliminado."
        })


    except ForeignKeyViolation:

        return jsonify({
            "error":
                "El producto posee "
                "información asociada."
        }), 400


    except Exception as error:

        print(
            "[ERROR eliminar]",
            error
        )

        return jsonify({
            "error":
                "No se pudo eliminar."
        }), 500


# ============================================================
# ADJUDICACIONES PENDIENTES
# ============================================================


@app.route("/api/adjudicaciones/pendientes", methods=["GET"])
def obtener_pendientes():
    try:
        with obtener_conexion() as conexion:
            live = obtener_live_activo(conexion)

            if not live:
                return jsonify([])

            with conexion.cursor() as cursor:
                cursor.execute("""
                    SELECT
                        p.codigo,
                        p.descripcion,
                        p.precio,
                        c.username AS usuario,
                        c.nickname,
                        TO_CHAR(a.fecha_hora, 'HH24:MI:SS') AS hora,
                        a.id_mensaje AS comentario_id,

                        COALESCE(
                            pe.estado_pago,
                            'pendiente_pago'
                        ) AS estado_pago,

                        EXTRACT(EPOCH FROM pe.plazo_pago_hasta)::bigint
                            AS plazo_pago_hasta_epoch,

                        EXISTS (
                            SELECT 1
                            FROM pago_flow pf
                            WHERE pf.id_pedido = pe.id_pedido
                              AND pf.estado IN ('creando', 'pendiente')
                        ) AS pago_en_proceso,

                        (
                            SELECT COUNT(*)
                            FROM lista_espera le
                            WHERE le.id_producto = p.id_producto
                              AND le.estado = 'esperando'
                        ) AS personas_esperando

                    FROM adjudicacion a

                    JOIN producto p
                        ON p.id_producto = a.id_producto

                    JOIN comprador c
                        ON c.id_comprador = a.id_comprador

                    LEFT JOIN detalle_pedido dp
                        ON dp.id_producto = p.id_producto

                    LEFT JOIN pedido pe
                        ON pe.id_pedido = dp.id_pedido
                       AND pe.id_comprador = a.id_comprador

                    WHERE p.id_live = %s
                      AND a.estado = 'aceptada'
                      AND (
                          p.estado = 'reservado'
                          OR (
                              p.estado = 'vendido'
                              AND pe.estado_pago = 'pagado'
                          )
                      )

                    ORDER BY
                        a.fecha_hora ASC,
                        a.id_adjudicacion ASC;
                """, (live["id_live"],))

                registros = cursor.fetchall()

        return jsonify(registros)

    except Exception as error:
        print("[ERROR adjudicaciones del Live]", error)

        return jsonify({
            "error": "No se pudieron cargar las adjudicaciones."
        }), 500



# ============================================================
# ALERTAS DE PRENDAS LIBERADAS
# ============================================================

@app.route("/api/alertas-prenda-liberada", methods=["GET"])
def obtener_alerta_prenda_liberada():
    id_usuario = session["id_usuario"]

    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute("""
                SELECT
                    a.id_alerta,
                    a.codigo,
                    a.descripcion,
                    a.resultado
                FROM alertas_prendas_liberadas a
                WHERE a.creada_en >=
                      NOW() - INTERVAL '24 hours'
                  AND NOT EXISTS (
                      SELECT 1
                      FROM alertas_prendas_aceptadas aa
                      WHERE aa.id_alerta = a.id_alerta
                        AND aa.id_usuario = %s
                  )
                ORDER BY a.id_alerta ASC
                LIMIT 1;
            """, (id_usuario,))

            alerta = cursor.fetchone()

    return jsonify(alerta)


@app.route(
    "/api/alertas-prenda-liberada/aceptar",
    methods=["POST"]
)
def aceptar_alerta_prenda_liberada():
    token_guardado = session.get(
        "csrf_configuracion", ""
    )
    token_recibido = request.headers.get(
        "X-CSRF-Token", ""
    )

    if (
        not token_guardado
        or not secrets.compare_digest(
            token_guardado, token_recibido
        )
    ):
        return jsonify({
            "error": "Token de seguridad inválido."
        }), 403

    datos = request.get_json(silent=True)

    if not isinstance(datos, dict):
        return jsonify({
            "error": "Solicitud inválida."
        }), 400

    id_alerta = datos.get("id_alerta")

    if (
        type(id_alerta) is not int
        or id_alerta <= 0
    ):
        return jsonify({
            "error": "Identificador de alerta inválido."
        }), 400

    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            
            cursor.execute("""
                INSERT INTO alertas_prendas_aceptadas (
                    id_alerta,
                    id_usuario
                )
                SELECT
                    a.id_alerta,
                    %s
                FROM alertas_prendas_liberadas a
                WHERE a.id_producto = (
                    SELECT id_producto
                    FROM alertas_prendas_liberadas
                    WHERE id_alerta = %s
                )
                AND a.creada_en <= NOW()
                ON CONFLICT DO NOTHING;
            """, (
                session["id_usuario"],
                id_alerta
            ))


    return jsonify({"ok": True})

# ============================================================
# HISTORIAL
# ============================================================

@app.route(
    "/api/adjudicaciones/historial",
    methods=["GET"]
)
def historial():

    try:

        with obtener_conexion() as conexion:

            live = obtener_live_activo(
                conexion
            )


            if not live:

                return jsonify([])


            with conexion.cursor() as cursor:

                cursor.execute(
                    """
                    SELECT
                        a.id_adjudicacion
                            AS id,

                        p.codigo,

                        p.descripcion,

                        p.precio,

                        c.username
                            AS usuario,

                        c.nickname,

                        a.estado,

                        TO_CHAR(
                            a.fecha_hora,
                            'HH24:MI:SS'
                        ) AS hora

                    FROM adjudicacion a

                    JOIN producto p
                        ON p.id_producto =
                           a.id_producto

                    JOIN comprador c
                        ON c.id_comprador =
                           a.id_comprador

                    WHERE
                        p.id_live = %s

                    ORDER BY
                        a.id_adjudicacion ASC;
                    """,
                    (
                        live[
                            "id_live"
                        ],
                    )
                )


                datos = (
                    cursor.fetchall()
                )


        return jsonify(datos)


    except Exception as error:

        print(
            "[ERROR historial]",
            error
        )

        return jsonify([])


# ============================================================
# ACEPTAR
# ============================================================

@app.route(
    "/api/adjudicaciones/<codigo>/aceptar",
    methods=["POST"]
)
def aceptar_adjudicacion(codigo):

    try:

        with obtener_conexion() as conexion:

            live = obtener_live_activo(
                conexion
            )


            if not live:

                return jsonify({
                    "error":
                        "No existe Live activo."
                }), 400


            with conexion.cursor() as cursor:

                # Producto bloqueado

                cursor.execute(
                    """
                    SELECT
                        id_producto,
                        precio

                    FROM producto

                    WHERE
                        id_live = %s
                        AND codigo = %s

                    FOR UPDATE;
                    """,
                    (
                        live[
                            "id_live"
                        ],

                        codigo
                    )
                )


                producto = (
                    cursor.fetchone()
                )


                if not producto:

                    return jsonify({
                        "error":
                            "Producto no encontrado."
                    }), 404


                # Candidato actual

                cursor.execute(
                    """
                    SELECT
                        a.id_adjudicacion,
                        a.id_comprador,
                        c.username

                    FROM adjudicacion a

                    JOIN comprador c
                        ON c.id_comprador =
                           a.id_comprador

                    WHERE
                        a.id_producto = %s
                        AND
                        a.estado = 'pendiente'

                    ORDER BY
                        a.id_adjudicacion DESC

                    LIMIT 1

                    FOR UPDATE;
                    """,
                    (
                        producto[
                            "id_producto"
                        ],
                    )
                )


                candidato = (
                    cursor.fetchone()
                )


                if not candidato:

                    return jsonify({
                        "error":
                            "No existe una "
                            "adjudicación pendiente."
                    }), 400


                cursor.execute(
                    """
                    UPDATE adjudicacion

                    SET estado = 'aceptada'

                    WHERE
                        id_adjudicacion = %s;
                    """,
                    (
                        candidato[
                            "id_adjudicacion"
                        ],
                    )
                )


                cursor.execute(
                    """
                    UPDATE producto

                    SET estado = 'reservado'

                    WHERE id_producto = %s;
                    """,
                    (
                        producto[
                            "id_producto"
                        ],
                    )
                )


                # Mantener también el pedido sincronizado si esta
                # ruta antigua de aceptación manual llegara a usarse.
                agregar_producto_a_pedido(
                    conexion=conexion,
                    id_live=live["id_live"],
                    id_comprador=candidato["id_comprador"],
                    id_producto=producto["id_producto"],
                    precio=producto["precio"]
                )


            conexion.commit()


        return jsonify({
            "mensaje":
                f"Producto adjudicado a "
                f"@{candidato['username']}."
        })


    except Exception as error:

        print(
            "[ERROR aceptar]",
            error
        )

        return jsonify({
            "error":
                "No se pudo aceptar "
                "la adjudicación."
        }), 500


# ============================================================
# CANCELAR Y PASAR AL SIGUIENTE
# ============================================================

@app.route(
    "/api/adjudicaciones/<codigo>/cancelar",
    methods=["POST"]
)
def cancelar_adjudicacion(codigo):

    try:

        with obtener_conexion() as conexion:

            live = obtener_live_activo(
                conexion
            )


            if not live:

                return jsonify({
                    "error":
                        "No existe Live activo."
                }), 400


            with conexion.cursor() as cursor:

                cursor.execute(
                    """
                    SELECT
                        id_producto,
                        precio,
                        estado

                    FROM producto

                    WHERE
                        id_live = %s
                        AND codigo = %s

                    FOR UPDATE;
                    """,
                    (
                        live[
                            "id_live"
                        ],

                        codigo
                    )
                )


                producto = (
                    cursor.fetchone()
                )


                if not producto:

                    return jsonify({
                        "error":
                            "Producto no encontrado."
                    }), 404

                
                if producto["estado"] == "vendido":
                    return jsonify({
                            "error": "No puedes cancelar un producto pagado."
                    }), 409

                if producto["estado"] != "reservado":
                    return jsonify({
                "error": "Solo puedes cancelar productos reservados."
                    }), 409



                id_producto = (
                    producto[
                        "id_producto"
                    ]
                )


                # ============================================
                # NO PERMITIR CANCELAR PRENDAS YA PAGADAS
                # ============================================

                cursor.execute(
                    """
                    SELECT
                        pe.id_pedido,
                        pe.estado_pago

                    FROM detalle_pedido dp

                    JOIN pedido pe
                        ON pe.id_pedido =
                           dp.id_pedido

                    WHERE
                        dp.id_producto = %s

                    LIMIT 1;
                    """,
                    (
                        id_producto,
                    )
                )


                pedido_producto = (
                    cursor.fetchone()
                )



                if (
                    pedido_producto
                    
                    and
                    pedido_producto[
                        "estado_pago"
                    ] == "pagado"

                    
                ):

                    return jsonify({
                        "error":
                            "No puedes cancelar una "
                            "prenda que ya fue pagada."
                    }), 400


                # No cancelar prendas con un pago Flow en proceso.
                cursor.execute(
                    """
                    SELECT 1
                    FROM pago_flow pf
                    JOIN detalle_pedido dp
                        ON dp.id_pedido = pf.id_pedido
                    WHERE dp.id_producto = %s
                      AND pf.estado IN ('creando', 'pendiente')
                    LIMIT 1;
                    """,
                    (id_producto,)
                )

                if cursor.fetchone():
                    return jsonify({
                        "error": (
                            "No puedes cancelar esta prenda "
                            "mientras exista un pago Flow en proceso."
                        )
                    }), 409


                # Candidato actual

                cursor.execute(
                    """
                    SELECT
                        a.id_adjudicacion,
                        a.id_comprador,
                        c.username

                    FROM adjudicacion a

                    JOIN comprador c
                        ON c.id_comprador =
                           a.id_comprador

                    WHERE
                        a.id_producto = %s
                        AND
                        a.estado = 'aceptada'

                    ORDER BY
                        a.id_adjudicacion DESC

                    LIMIT 1

                    FOR UPDATE;
                    """,
                    (
                        id_producto,
                    )
                )


                actual = (
                    cursor.fetchone()
                )


                if not actual:

                    return jsonify({
                        "error":
                            "No hay una "
                            "adjudicación activa."
                    }), 400


                cursor.execute(
                    """
                    UPDATE adjudicacion

                    SET estado = 'cancelada'

                    WHERE
                        id_adjudicacion = %s;
                    """,
                    (
                        actual[
                            "id_adjudicacion"
                        ],
                    )
                )


                # Quitar la prenda del pedido de la persona cancelada.
                quitar_producto_de_pedido(
                    conexion,
                    id_producto
                )


                # ============================================
                # SIGUIENTE PERSONA
                # ============================================

                cursor.execute(
                    """
                    SELECT
                        le.id_lista_espera,
                        le.id_comprador,
                        le.id_mensaje,
                        le.posicion,
                        c.username

                    FROM lista_espera le

                    JOIN comprador c
                        ON c.id_comprador =
                           le.id_comprador

                    WHERE
                        le.id_producto = %s
                        AND
                        le.estado = 'esperando'

                    ORDER BY
                        le.posicion ASC

                    LIMIT 1

                    FOR UPDATE;
                    """,
                    (
                        id_producto,
                    )
                )


                siguiente = (
                    cursor.fetchone()
                )


                if siguiente:

                    # Lo sacamos de espera

                    cursor.execute(
                        """
                        UPDATE lista_espera

                        SET estado = 'promovido'

                        WHERE
                            id_lista_espera = %s;
                        """,
                        (
                            siguiente[
                                "id_lista_espera"
                            ],
                        )
                    )


                    # Creamos nueva adjudicación

                    cursor.execute(
                        """
                        INSERT INTO adjudicacion (
                            id_producto,
                            id_comprador,
                            id_mensaje,
                            tipo,
                            estado
                        )

                        VALUES (
                            %s,
                            %s,
                            %s,
                            'automatica',
                            'aceptada'
                        );
                        """,
                        (
                            id_producto,

                            siguiente[
                                "id_comprador"
                            ],

                            siguiente[
                                "id_mensaje"
                            ]
                        )
                    )


                    # Ajustar posiciones restantes

                    cursor.execute(
                        """
                        UPDATE lista_espera

                        SET
                            posicion =
                                posicion - 1

                        WHERE
                            id_producto = %s
                            AND
                            estado = 'esperando'
                            AND
                            posicion >
                                %s;
                        """,
                        (
                            id_producto,

                            siguiente[
                                "posicion"
                            ]
                        )
                    )


                    cursor.execute(
                        """
                        UPDATE producto

                        SET estado = 'reservado'

                        WHERE
                            id_producto = %s;
                        """,
                        (
                            id_producto,
                        )
                    )

                    # Agregar la prenda al pedido de la nueva compradora.
                    agregar_producto_a_pedido(
                        conexion=conexion,
                        id_live=live["id_live"],
                        id_comprador=siguiente["id_comprador"],
                        id_producto=id_producto,
                        precio=producto["precio"]
                    )


                    mensaje = (
                        f"Se canceló a "
                        f"@{actual['username']}. "
                        f"Ahora sigue "
                        f"@{siguiente['username']}."
                    )


                else:

                    cursor.execute(
                        """
                        UPDATE producto

                        SET estado = 'disponible'

                        WHERE
                            id_producto = %s;
                        """,
                        (
                            id_producto,
                        )
                    )


                    mensaje = (
                        f"Se canceló a "
                        f"@{actual['username']}. "
                        f"No quedan personas "
                        f"en espera."
                    )


            conexion.commit()


        return jsonify({
            "mensaje":
                mensaje
        })


    except Exception as error:

        print(
            "[ERROR cancelar]",
            error
        )

        return jsonify({
            "error":
                "No se pudo cancelar."
        }), 500


# ============================================================
# EJECUTAR
# ============================================================
@app.route("/api/live/actual", methods=["GET"])
def consultar_live_actual():
    with obtener_conexion() as conexion:
        live = obtener_live_activo(conexion)

    return jsonify(dict(live) if live else None)



@app.route("/api/live/preparar", methods=["POST"])
def preparar_live():

    datos = request.get_json(silent=True) or {}

    titulo = str(
        datos.get("titulo", "")
    ).strip()

    cuenta = str(
        datos.get("cuenta_tiktok") or ""
    ).strip().lower().lstrip("@")

    # Validar nombre de transmisión
    if not titulo or len(titulo) > 150:
        return jsonify({
            "error": (
                "Ingresa un título de entre "
                "1 y 150 caracteres."
            )
        }), 400

    # Validar usuario de TikTok
    if not re.fullmatch(r"[a-z0-9._]{2,24}", cuenta):
        return jsonify({
            "error": "Ingresa una cuenta de TikTok válida."
        }), 400

    cuenta_tiktok = "@" + cuenta

    with obtener_conexion() as conexion:

        with conexion.cursor() as cursor:

            # Bloqueo compartido para impedir
            # crear dos Lives simultáneamente.
            cursor.execute(
                "SELECT pg_advisory_xact_lock(hashtext(%s));",
                ("socialsale_live_global",)
            )

            actual = obtener_live_activo(conexion)

            if actual:
                return jsonify({
                    "error": (
                        "Ya existe un Live en preparación "
                        "o en curso. Finalízalo primero."
                    )
                }), 409

            # Guardar la cuenta elegida para este Live.
            # id_usuario representa al creador del Live,
            # no una vinculación fija con TikTok.
            cursor.execute(
                """
                INSERT INTO live (
                    id_usuario,
                    titulo,
                    cuenta_tiktok,
                    estado
                )

                VALUES (
                    %s,
                    %s,
                    %s,
                    'preparacion'
                )

                RETURNING
                    id_live,
                    titulo,
                    cuenta_tiktok,
                    estado;
                """,
                (
                    session["id_usuario"],
                    titulo,
                    cuenta_tiktok
                )
            )

            nuevo = cursor.fetchone()

    return jsonify(dict(nuevo)), 201



@app.route("/api/live/iniciar", methods=["POST"])
def iniciar_live_preparado():
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            
            cursor.execute(
                "SELECT pg_advisory_xact_lock(hashtext(%s));",
                ("socialsale_live_global",)
            )

            live = obtener_live_activo(conexion)

            if not live or live["estado"] != "preparacion":
                return jsonify({
                    "error": "No hay un live en preparación."
                }), 400

            cursor.execute(
                "SELECT COUNT(*) AS total FROM producto WHERE id_live = %s;",
                (live["id_live"],)
            )

            if cursor.fetchone()["total"] == 0:
                return jsonify({
                    "error": "Agrega al menos un producto antes de iniciar."
                }), 400

            cursor.execute(
                """
                UPDATE live
                SET estado = 'en_curso', fecha_inicio = NOW()
                WHERE id_live = %s
                RETURNING id_live, titulo, cuenta_tiktok, estado;
                """,
                (live["id_live"],)
            )
            iniciado = cursor.fetchone()

    return jsonify(dict(iniciado))


@app.route("/api/live/finalizar", methods=["POST"])
def finalizar_live_actual():
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            
            cursor.execute(
                "SELECT pg_advisory_xact_lock(hashtext(%s));",
                ("socialsale_live_global",)
            )

            live = obtener_live_activo(conexion)

            if not live:
                return jsonify({"error": "No hay un live activo."}), 400

            cursor.execute(
                """
                UPDATE live
                SET estado = 'finalizado', fecha_fin = NOW()
                WHERE id_live = %s;
                """,
                (live["id_live"],)
            )

    return jsonify({"mensaje": "Live finalizado."})

@app.route("/api/reportes/lives", methods=["GET"])
def listar_lives_reportes():
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                SELECT
                    l.id_live,
                    l.titulo,
                    l.cuenta_tiktok,
                    l.estado,
                    l.fecha_creacion,
                    l.fecha_inicio,
                    l.fecha_fin,
                    (SELECT COUNT(*)
                     FROM producto p
                     WHERE p.id_live = l.id_live) AS productos,
                    (SELECT COUNT(*)
                     FROM mensaje_chat m
                     WHERE m.id_live = l.id_live) AS comentarios
                
                FROM live l
                ORDER BY l.id_live DESC;
                """
            )
            lives = cursor.fetchall()

    return jsonify(lives)


@app.route("/api/reportes/lives/<int:id_live>", methods=["GET"])
def detalle_live_reporte(id_live):
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            # El historial incluye transmisiones de todas las cuentas.
            cursor.execute(
                """
                SELECT id_live, titulo, cuenta_tiktok, estado,
                       fecha_creacion, fecha_inicio, fecha_fin
                FROM live
                WHERE id_live = %s;
                """,
                (id_live,)
            )
            live = cursor.fetchone()

            if not live:
                return jsonify({"error": "Live no encontrado."}), 404

            cursor.execute(
                """
                SELECT id_producto, codigo, descripcion, precio, estado
                FROM producto
                WHERE id_live = %s
                ORDER BY id_producto;
                """,
                (id_live,)
            )
            productos = cursor.fetchall()

            cursor.execute(
                """
                SELECT
                    a.id_adjudicacion,
                    p.codigo,
                    p.descripcion,
                    p.precio,
                    c.username,
                    a.tipo,
                    a.estado,
                    a.fecha_hora
                FROM adjudicacion a
                JOIN producto p ON p.id_producto = a.id_producto
                JOIN comprador c ON c.id_comprador = a.id_comprador
                WHERE p.id_live = %s
                ORDER BY a.id_adjudicacion;
                """,
                (id_live,)
            )
            adjudicaciones = cursor.fetchall()

            cursor.execute(
                """
                SELECT
                    p.codigo,
                    c.username,
                    le.posicion,
                    le.estado,
                    le.fecha_hora
                FROM lista_espera le
                JOIN producto p ON p.id_producto = le.id_producto
                JOIN comprador c ON c.id_comprador = le.id_comprador
                WHERE p.id_live = %s
                ORDER BY p.codigo, le.posicion, le.id_lista_espera;
                """,
                (id_live,)
            )
            espera = cursor.fetchall()

            cursor.execute(
                """
                SELECT orden_recepcion, username, contenido,
                       fecha_hora, codigo_detectado, intencion_compra
                FROM mensaje_chat
                WHERE id_live = %s
                ORDER BY orden_recepcion;
                """,
                (id_live,)
            )
            comentarios = cursor.fetchall()


            # Total de pedidos realmente pagados del Live
            cursor.execute("""
                SELECT
                    COALESCE(SUM(total), 0) AS monto_pagado
                FROM pedido
                WHERE id_live = %s
                  AND estado_pago = 'pagado';
            """, (id_live,))

            monto_pagado = cursor.fetchone()["monto_pagado"]


    reservados = [
        p for p in productos if p["estado"] == "reservado"
    ]

    resumen = {
        "productos": len(productos),
        "comentarios": len(comentarios),
        "productos_reservados": len(reservados),
        "monto_reservado": sum(p["precio"] for p in reservados),
        "monto_pagado": monto_pagado,
        "adjudicaciones_canceladas": sum(
            a["estado"] == "cancelada" for a in adjudicaciones
        ),
        "personas_en_espera": sum(
            persona["estado"] == "esperando" for persona in espera
        )
        
    }

    return jsonify({
        "live": live,
        "resumen": resumen,
        "productos": productos,
        "adjudicaciones": adjudicaciones,
        "lista_espera": espera,
        "comentarios": comentarios
    })
# ============================================================
# CLIENTES / PEDIDOS
# ============================================================

@app.route(
    "/api/clientes",
    methods=["GET"]
)
def obtener_clientes():

    try:

        with obtener_conexion() as conexion:

            with conexion.cursor() as cursor:

                cursor.execute(
                    """
                    SELECT
                        c.id_comprador,
                        c.username,
                        c.nickname,

                        pe.id_pedido,
                        pe.total,
                        pe.estado_pago,
                        pe.estado_preparacion,
                        pe.fecha_creacion,
                        pe.fecha_pago,
                        pe.pago_expirado_en,

                        l.id_live,
                        l.titulo AS titulo_live,
                        l.fecha_inicio,

                        pr.id_producto,
                        pr.codigo,
                        pr.descripcion,
                        dp.precio_unitario

                    FROM pedido pe

                    JOIN comprador c
                        ON c.id_comprador =
                           pe.id_comprador

                    JOIN live l
                        ON l.id_live =
                           pe.id_live

                    LEFT JOIN detalle_pedido dp
                        ON dp.id_pedido =
                           pe.id_pedido

                    LEFT JOIN producto pr
                        ON pr.id_producto =
                           dp.id_producto

                    ORDER BY
                        c.username ASC,
                        COALESCE(
                            l.fecha_inicio,
                            pe.fecha_creacion
                        ) DESC,
                        pe.id_pedido DESC,
                        dp.id_detalle ASC;
                    """
                )

                filas = cursor.fetchall()


        # ----------------------------------------------------
        # AGRUPAR:
        #
        # Cliente
        #   └── Pedido
        #         └── Productos
        # ----------------------------------------------------

        clientes = {}

        for fila in filas:

            id_comprador = fila[
                "id_comprador"
            ]

            if id_comprador not in clientes:

                clientes[id_comprador] = {
                    "id_comprador": id_comprador,
                    "username": fila["username"],
                    "nickname": fila["nickname"],
                    "pedidos": []
                }


            cliente = clientes[
                id_comprador
            ]


            pedido = next(
                (
                    item
                    for item
                    in cliente["pedidos"]

                    if item["id_pedido"]
                    == fila["id_pedido"]
                ),
                None
            )


            if pedido is None:

                pedido = {
                    "id_pedido": fila["id_pedido"],
                    "id_live": fila["id_live"],
                    "titulo_live": fila["titulo_live"],
                    "fecha_live": fila["fecha_inicio"],
                    "total": fila["total"],
                    "estado_pago": (
                        "expirado"
                        if fila["pago_expirado_en"] is not None
                        else fila["estado_pago"]
                    ),
                    "estado_preparacion": fila[
                        "estado_preparacion"
                    ],
                    "fecha_creacion": fila["fecha_creacion"],
                    "fecha_pago": fila["fecha_pago"],
                    "productos": []
                }

                cliente["pedidos"].append(
                    pedido
                )


            if fila["id_producto"] is not None:

                pedido["productos"].append({
                    "id_producto": fila["id_producto"],
                    "codigo": fila["codigo"],
                    "descripcion": fila["descripcion"],
                    "precio": fila["precio_unitario"]
                })


        return jsonify(
            list(clientes.values())
        )


    except Exception as error:

        print(
            "[ERROR clientes]",
            error
        )

        return jsonify({
            "error":
                "No se pudieron cargar "
                "los clientes."
        }), 500


# ============================================================
# MARCAR PEDIDO COMO PAGADO
# ============================================================


@app.route(
    "/api/pedidos/<int:id_pedido>/pagar",
    methods=["POST"]
)
def marcar_pedido_pagado(id_pedido):
    return jsonify({
        "error": (
            "La confirmación manual está deshabilitada. "
            "Utiliza el pago verificado mediante Flow."
        )
    }), 409


# ============================================================
# MARCAR PEDIDO COMO PREPARADO
# ============================================================

@app.route(
    "/api/pedidos/<int:id_pedido>/preparar",
    methods=["POST"]
)
def marcar_pedido_preparado(id_pedido):

    try:

        with obtener_conexion() as conexion:

            with conexion.cursor() as cursor:

                cursor.execute(
                    """
                    SELECT
                        pe.id_pedido,
                        pe.estado_pago,
                        pe.estado_preparacion

                    FROM pedido pe

                    JOIN live l
                        ON l.id_live =
                           pe.id_live

                    WHERE
                        pe.id_pedido = %s

                    FOR UPDATE OF pe;
                    """,
                    (
                        id_pedido,
                    )
                )

                pedido = cursor.fetchone()


                if not pedido:

                    return jsonify({
                        "error":
                            "Pedido no encontrado."
                    }), 404


                # Un pedido no debería prepararse antes
                # de que la vendedora confirme su pago.
                if (
                    pedido["estado_pago"]
                    != "pagado"
                ):

                    return jsonify({
                        "error":
                            "Primero debes marcar "
                            "el pedido como pagado."
                    }), 400


                if (
                    pedido[
                        "estado_preparacion"
                    ] == "preparado"
                ):

                    return jsonify({
                        "mensaje":
                            "El pedido ya está preparado."
                    })


                cursor.execute(
                    """
                    UPDATE pedido

                    SET
                        estado_preparacion =
                            'preparado'

                    WHERE id_pedido = %s;
                    """,
                    (
                        id_pedido,
                    )
                )


            conexion.commit()


        return jsonify({
            "mensaje":
                "Pedido marcado como preparado."
        })


    except Exception as error:

        print(
            "[ERROR preparar pedido]",
            error
        )

        return jsonify({
            "error":
                "No se pudo actualizar "
                "el pedido."
        }), 500

# ============================================================
# ENLACE ÚNICO DEL PEDIDO
# ============================================================

@app.route("/api/carritos/enlace", methods=["POST"])
def crear_enlace_carrito():
    datos = request.get_json(silent=True) or {}
    usuario = datos.get("username")

    if not isinstance(usuario, str) or not usuario.strip():
        return jsonify({
            "error": "Selecciona un comprador válido."
        }), 400

    with obtener_conexion() as conexion:
        live = obtener_live_activo(conexion)

        if not live:
            return jsonify({
                "error": "No hay un live activo."
            }), 409

        with conexion.cursor() as cursor:
            # Busca el pedido del comprador en el live actual.
            cursor.execute(
                """
                SELECT
                    pe.id_pedido,
                    pe.token_carrito,
                    c.username,
                    pe.estado_pago,
                    pe.pago_expirado_en,
                    (
                    pe.plazo_pago_hasta IS NOT NULL
                    AND pe.plazo_pago_hasta <= NOW()
                    ) AS plazo_vencido

                FROM pedido pe

                JOIN comprador c
                    ON c.id_comprador = pe.id_comprador

                JOIN live l
                    ON l.id_live = pe.id_live

                WHERE pe.id_live = %s
                  AND c.username = %s

                  
AND EXISTS (
    SELECT 1
    FROM detalle_pedido dp
    WHERE dp.id_pedido = pe.id_pedido
)

ORDER BY
    CASE
        WHEN pe.estado_pago = 'pendiente_pago'
            THEN 0
        ELSE 1
    END,
    pe.id_pedido DESC

LIMIT 1

FOR UPDATE OF pe;

                """,
                (
                    live["id_live"],
                    usuario
                )
            )

            pedido = cursor.fetchone()

            if not pedido:
                return jsonify({
                    "error": (
                        "Este comprador no tiene un pedido "
                        "con productos en este live."
                    )
                }), 404

            if pedido["estado_pago"] == "pagado":
                return jsonify({
                    "error": "Este pedido ya está pagado."
                }), 409

            # Conserva el enlace si ya se generó anteriormente.
            
            # El primer clic inicia los 20 minutos.
            # Volver a copiar no reinicia el tiempo.
            if (
                pedido["pago_expirado_en"] is not None
                or pedido["plazo_vencido"]
            ):
                return jsonify({
                    "error": "El plazo de este pedido ya venció."
                }), 409

            token = (
                pedido["token_carrito"]
                or secrets.token_urlsafe(32)
            )

            cursor.execute("""
                UPDATE pedido
                SET token_carrito = COALESCE(token_carrito, %s),
                    plazo_pago_hasta = COALESCE(
                        plazo_pago_hasta,
                        NOW() + INTERVAL '6 minutes'
                    )
                WHERE id_pedido = %s
                RETURNING
                    EXTRACT(EPOCH FROM plazo_pago_hasta)::bigint
                    AS plazo_pago_hasta_epoch;
            """, (token, pedido["id_pedido"]))

            plazo = cursor.fetchone()["plazo_pago_hasta_epoch"]


    ruta = url_for("ver_carrito", token=token)

    base_publica = os.environ.get(
        "PUBLIC_BASE_URL", ""
    ).strip().rstrip("/")

    enlace = (
        base_publica + ruta
        if base_publica
        else url_for(
            "ver_carrito",
            token=token,
            _external=True
        )
    )

    respuesta = jsonify({
        "url": enlace,
        "username": pedido["username"],
        "plazo_pago_hasta_epoch": plazo
    })

    respuesta.headers["Cache-Control"] = "no-store"

    return respuesta


# ============================================================
# PÁGINA DEL PEDIDO DEL COMPRADOR
# ============================================================

@app.route("/carrito/<token>", methods=["GET"])
def ver_carrito(token):
    pedido = None
    productos = []
    pago_flow = None

    if re.fullmatch(r"[A-Za-z0-9_-]{43}", token):
        with obtener_conexion() as conexion:
            with conexion.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT
                        pe.id_pedido,
                        pe.estado_pago,
                        pe.estado_preparacion,
                        pe.fecha_creacion,
                        pe.fecha_pago,
                        pe.plazo_pago_hasta,
                        pe.pago_expirado_en,
                        (
                            pe.plazo_pago_hasta IS NOT NULL
                            AND pe.plazo_pago_hasta <= NOW()
                        ) AS plazo_vencido,

                        c.username,
                        c.nickname,

                        l.titulo AS titulo_live,
                        l.estado AS estado_live,
                        l.fecha_inicio,
                        l.fecha_fin

                    FROM pedido pe

                    JOIN comprador c
                        ON c.id_comprador = pe.id_comprador

                    JOIN live l
                        ON l.id_live = pe.id_live

                    WHERE pe.token_carrito = %s;
                    """,
                    (
                        token,
                    )
                )

                pedido = cursor.fetchone()

                if pedido:
                    cursor.execute(
                        """
                        SELECT
                            pr.codigo,
                            pr.descripcion,
                            pr.estado,
                            dp.precio_unitario

                        FROM detalle_pedido dp

                        JOIN producto pr
                            ON pr.id_producto = dp.id_producto

                        WHERE dp.id_pedido = %s

                        ORDER BY dp.id_detalle;
                        """,
                        (
                            pedido["id_pedido"],
                        )
                    )

                    productos = cursor.fetchall()


                    cursor.execute(
                        """
                        SELECT
                            estado,
                            url_pago,
                            actualizado_en
                        FROM pago_flow
                        WHERE id_pedido = %s
                        ORDER BY id_pago_flow DESC
                        LIMIT 1;
                        """,
                        (pedido["id_pedido"],)
                    )

                    pago_flow = cursor.fetchone()


    total = sum(
        producto["precio_unitario"]
        for producto in productos
    )

    respuesta = app.make_response((
        
render_template(
    "carrito.html",
    pedido=pedido,
    productos=productos,
    total=total,
    token=token,
    pago_flow=pago_flow,
    flow_habilitado=(
        os.getenv("FLOW_PAGOS_HABILITADOS", "0") == "1"
    )
)

    ))

    respuesta.headers["Cache-Control"] = "no-store, private"
    respuesta.headers["Referrer-Policy"] = "no-referrer"
    respuesta.headers["X-Robots-Tag"] = "noindex, nofollow, noarchive"
    respuesta.headers["X-Content-Type-Options"] = "nosniff"

    
    respuesta.headers["Content-Security-Policy"] = (
    "default-src 'none'; "
    "style-src 'unsafe-inline'; "
    "frame-ancestors 'none'; "
    "base-uri 'none'; "
    "form-action 'self' "
    "https://flow.cl https://*.flow.cl"
)


    return respuesta

# ============================================================
# PAGO DEL CARRITO - SIMULACIÓN DESHABILITADA
# ============================================================

@app.route("/carrito/<token>/pagar", methods=["POST"])
def pagar_desde_carrito(token):

    abort(
        410,
        description=(
            "El pago simulado fue deshabilitado. "
            "Utiliza la pasarela de pago verificada."
        )
    )


if __name__ == "__main__":

    hilo_tiktok = Thread(
        target=iniciar_captura,
        daemon=True
    )


    hilo_tiktok.start()

    hilo_plazos = Thread(
        target=ejecutar_bucle_vencimientos,
        daemon=True
    )
    hilo_plazos.start()


    print("")
    print("=" * 55)
    print("SOCIALSALE INICIADO")
    print("=" * 55)

    print("")
    print(
        "Abre: http://127.0.0.1:5000"
    )
    print("")


    app.run(
        host="127.0.0.1",
        port=5000,
        debug=False,
        use_reloader=False
    )

