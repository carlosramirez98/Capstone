
"""Control de plazos de reserva y reasignación automática."""

import time

from db import obtener_conexion
from flow_pago import consultar_pago_flow, consultar_pago_por_orden
from flow_integracion import _aplicar_estado_confirmado
from pedidos import agregar_producto_a_pedido


def verificar_flow(id_pedido):
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute("""
                SELECT token_flow, orden_comercio
                FROM pago_flow
                WHERE id_pedido = %s
                  AND estado IN ('creando', 'pendiente')
                ORDER BY id_pago_flow DESC
                LIMIT 1;
            """, (id_pedido,))
            activo = cursor.fetchone()

    if not activo:
        return

    if activo["token_flow"]:
        resultado = consultar_pago_flow(activo["token_flow"])
        _aplicar_estado_confirmado(
            resultado, activo["token_flow"]
        )
    else:
        resultado = consultar_pago_por_orden(
            activo["orden_comercio"]
        )
        _aplicar_estado_confirmado(resultado)


def vencer_pedido(id_pedido):
    try:
        verificar_flow(id_pedido)
    except Exception as error:
        print(
            "[PLAZOS] Pago pendiente de conciliación:",
            id_pedido, type(error).__name__
        )
        return

    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:

            # Mismo orden de bloqueos que la confirmación de Flow.
            cursor.execute("""
                    SELECT
                        pr.id_producto,
                        pr.codigo,
                        pr.descripcion,
                        pr.precio,
                        pr.estado
                FROM producto pr
                JOIN detalle_pedido dp
                  ON dp.id_producto = pr.id_producto
                WHERE dp.id_pedido = %s
                ORDER BY pr.id_producto
                FOR UPDATE OF pr;
            """, (id_pedido,))
            productos = cursor.fetchall()

            cursor.execute("""
                SELECT id_pedido, id_live, id_comprador,
                       estado_pago, pago_expirado_en,
                       (
                           plazo_pago_hasta IS NOT NULL
                           AND plazo_pago_hasta <= NOW()
                       ) AS vencido
                FROM pedido
                WHERE id_pedido = %s
                FOR UPDATE;
            """, (id_pedido,))
            pedido = cursor.fetchone()

            if (
                not pedido
                or pedido["estado_pago"] != "pendiente_pago"
                or pedido["pago_expirado_en"] is not None
                or not pedido["vencido"]
            ):
                return

            # Nunca liberar pedidos con cobros activos o confirmados.
            cursor.execute("""
                SELECT 1
                FROM pago_flow
                WHERE id_pedido = %s
                  AND estado IN ('creando', 'pendiente', 'pagado')
                LIMIT 1;
            """, (id_pedido,))

            if cursor.fetchone():
                return

            if any(
                producto["estado"] != "reservado"
                for producto in productos
            ):
                raise RuntimeError(
                    "El pedido tiene un estado inesperado."
                )

            for producto in productos:
                id_producto = producto["id_producto"]

                cursor.execute("""
                    SELECT id_adjudicacion
                    FROM adjudicacion
                    WHERE id_producto = %s
                      AND id_comprador = %s
                      AND estado = 'aceptada'
                    ORDER BY id_adjudicacion DESC
                    LIMIT 1
                    FOR UPDATE;
                """, (
                    id_producto,
                    pedido["id_comprador"]
                ))
                adjudicacion = cursor.fetchone()

                if not adjudicacion:
                    raise RuntimeError(
                        "Adjudicación activa no encontrada."
                    )

                cursor.execute("""
                    UPDATE adjudicacion
                    SET estado = 'cancelada'
                    WHERE id_adjudicacion = %s;
                """, (adjudicacion["id_adjudicacion"],))

                cursor.execute("""
                    DELETE FROM detalle_pedido
                    WHERE id_pedido = %s
                      AND id_producto = %s;
                """, (id_pedido, id_producto))

                # Obtener el primer comprador de la lista.
                cursor.execute("""
                    SELECT id_lista_espera, id_comprador,
                           id_mensaje, posicion
                    FROM lista_espera
                    WHERE id_producto = %s
                      AND estado = 'esperando'
                    ORDER BY posicion, id_lista_espera
                    LIMIT 1
                    FOR UPDATE;
                """, (id_producto,))
                siguiente = cursor.fetchone()

                if siguiente:
                    cursor.execute("""
                        UPDATE lista_espera
                        SET estado = 'promovido'
                        WHERE id_lista_espera = %s;
                    """, (siguiente["id_lista_espera"],))

                    cursor.execute("""
                        UPDATE lista_espera
                        SET posicion = posicion - 1
                        WHERE id_producto = %s
                          AND estado = 'esperando'
                          AND posicion > %s;
                    """, (
                        id_producto,
                        siguiente["posicion"]
                    ))

                    cursor.execute("""
                        INSERT INTO adjudicacion (
                            id_producto, id_comprador,
                            id_mensaje, tipo, estado
                        )
                        VALUES (
                            %s, %s, %s, 'automatica', 'aceptada'
                        );
                    """, (
                        id_producto,
                        siguiente["id_comprador"],
                        siguiente["id_mensaje"]
                    ))

                    cursor.execute("""
                        UPDATE producto
                        SET estado = 'reservado'
                        WHERE id_producto = %s;
                    """, (id_producto,))

                    agregar_producto_a_pedido(
                        conexion=conexion,
                        id_live=pedido["id_live"],
                        id_comprador=siguiente["id_comprador"],
                        id_producto=id_producto,
                        precio=producto["precio"]
                    )
                else:
                    cursor.execute("""
                        UPDATE producto
                        SET estado = 'disponible'
                        WHERE id_producto = %s;
                    """, (id_producto,))

                
                # Registrar aviso solamente después de
                # procesar la liberación de la prenda.
                cursor.execute("""
                    INSERT INTO alertas_prendas_liberadas (
                        id_pedido,
                        id_producto,
                        codigo,
                        descripcion,
                        resultado
                    )
                    VALUES (%s, %s, %s, %s, %s);
                """, (
                    id_pedido,
                    id_producto,
                    producto["codigo"],
                    producto["descripcion"],
                    "reasignada" if siguiente else "disponible"
                ))


            cursor.execute("""
                UPDATE pedido
                SET pago_expirado_en = NOW(),
                    total = 0
                WHERE id_pedido = %s;
            """, (id_pedido,))

    print("[PLAZOS] Reserva liberada:", id_pedido)


def revisar_vencimientos():
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute("""
                SELECT id_pedido
                FROM pedido
                WHERE estado_pago = 'pendiente_pago'
                  AND pago_expirado_en IS NULL
                  AND plazo_pago_hasta <= NOW()
                ORDER BY plazo_pago_hasta
                LIMIT 25;
            """)
            pedidos = [
                fila["id_pedido"]
                for fila in cursor.fetchall()
            ]

    for id_pedido in pedidos:
        try:
            vencer_pedido(id_pedido)
        except Exception as error:
            print(
                "[PLAZOS] No se liberó:",
                id_pedido, type(error).__name__
            )


def revisar_pagos_flow_activos():
    """
    Consulta las órdenes activas y sincroniza
    sus estados reales con PostgreSQL.
    """
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute("""
                SELECT DISTINCT pf.id_pedido
                FROM pago_flow pf
                JOIN pedido pe
                    ON pe.id_pedido = pf.id_pedido
                WHERE pf.estado IN ('creando', 'pendiente')
                  AND pe.estado_pago = 'pendiente_pago'
                  AND pe.pago_expirado_en IS NULL
                ORDER BY pf.id_pedido
                LIMIT 10;
            """)

            pedidos = [
                fila["id_pedido"]
                for fila in cursor.fetchall()
            ]

    for id_pedido in pedidos:
        try:
            verificar_flow(id_pedido)
        except Exception as error:
            print(
                "[FLOW] Pendiente de verificación:",
                id_pedido,
                type(error).__name__
            )




def ejecutar_bucle_vencimientos():
    ciclos = 0

    while True:
        try:
            # Revisar reservas vencidas cada 5 segundos
            revisar_vencimientos()

            # Sincronizar pagos Flow cada 15 segundos
            if ciclos % 3 == 0:
                revisar_pagos_flow_activos()

        except Exception as error:
            print(
                "[PLAZOS/FLOW] Error:",
                type(error).__name__
            )

        ciclos += 1
        time.sleep(5)

