
class PedidoBloqueadoError(RuntimeError):
    pass


def verificar_pedido_modificable(conexion, id_pedido):

    with conexion.cursor() as cursor:

        cursor.execute(
            """
            SELECT estado_pago
            FROM pedido
            WHERE id_pedido = %s
            FOR UPDATE;
            """,
            (id_pedido,)
        )

        pedido = cursor.fetchone()

        if not pedido:
            raise PedidoBloqueadoError(
                "El pedido no existe."
            )

        if pedido["estado_pago"] == "pagado":
            raise PedidoBloqueadoError(
                "El pedido ya fue pagado."
            )

        cursor.execute(
            """
            SELECT 1
            FROM pago_flow
            WHERE id_pedido = %s
              AND estado IN ('creando', 'pendiente')
            LIMIT 1;
            """,
            (id_pedido,)
        )

        if cursor.fetchone():
            raise PedidoBloqueadoError(
                "El pedido tiene un pago Flow en proceso."
            )


# ============================================================
# FUNCIONES DE PEDIDOS
# ============================================================



def recalcular_total_pedido(
    conexion,
    id_pedido
):

    with conexion.cursor() as cursor:

        cursor.execute(
            """
            UPDATE pedido

            SET total = COALESCE(
                (
                    SELECT SUM(
                        precio_unitario
                    )

                    FROM detalle_pedido

                    WHERE id_pedido = %s
                ),
                0
            )

            WHERE id_pedido = %s;
            """,
            (
                id_pedido,
                id_pedido
            )
        )


# ============================================================
# AGREGAR PRODUCTO A PEDIDO
# ============================================================

def agregar_producto_a_pedido(
        
    conexion,
    id_live,
    id_comprador,
    id_producto,
    precio
):

    

    with conexion.cursor() as cursor:

        # ----------------------------------------------------
        # CREAR PEDIDO SI TODAVÍA NO EXISTE PARA ESTE LIVE
        # ----------------------------------------------------

        cursor.execute(
            """
            INSERT INTO pedido (
                id_comprador,
                id_live,
                total,
                estado_pago,
                estado_preparacion
            )

            VALUES (
                %s,
                %s,
                0,
                'pendiente_pago',
                'por_preparar'
            )
  
            ON CONFLICT (
                id_live,
                id_comprador
            )
            WHERE estado_pago = 'pendiente_pago'
            
            DO UPDATE SET
                id_comprador =
                    EXCLUDED.id_comprador

            RETURNING id_pedido;

            """,
            (
                id_comprador,
                id_live
            )
        )


        pedido = cursor.fetchone()

        id_pedido = pedido[
            "id_pedido"
        ]

        verificar_pedido_modificable(conexion, id_pedido)


        cursor.execute("""
            UPDATE pedido
            SET pago_expirado_en = NULL,
                plazo_pago_hasta = NULL,
                token_carrito = NULL
            WHERE id_pedido = %s
              AND pago_expirado_en IS NOT NULL;
        """, (id_pedido,))



        # ----------------------------------------------------
        # AGREGAR PRODUCTO AL PEDIDO
        # ----------------------------------------------------

        cursor.execute(
            """
            INSERT INTO detalle_pedido (
                id_pedido,
                id_producto,
                precio_unitario
            )

            VALUES (
                %s,
                %s,
                %s
            )

            ON CONFLICT (
                id_producto
            )

            DO NOTHING;
            """,
            (
                id_pedido,
                id_producto,
                precio
            )
        )


    recalcular_total_pedido(
        conexion,
        id_pedido
    )


    return id_pedido


# ============================================================
# QUITAR PRODUCTO DE UN PEDIDO
#
# Se usa cuando una adjudicación es cancelada.
# ============================================================

def quitar_producto_de_pedido(
    conexion,
    id_producto
):

    with conexion.cursor() as cursor:

        cursor.execute(
            """
            SELECT id_pedido

            FROM detalle_pedido

            WHERE id_producto = %s

            LIMIT 1;
            """,
            (
                id_producto,
            )
        )


        detalle = cursor.fetchone()


        if not detalle:

            return


        id_pedido = detalle[
            "id_pedido"
        ]

        verificar_pedido_modificable(conexion, id_pedido)


        cursor.execute(
            """
            DELETE FROM detalle_pedido

            WHERE id_producto = %s;
            """,
            (
                id_producto,
            )
        )


        cursor.execute(
            """
            SELECT COUNT(*) AS total

            FROM detalle_pedido

            WHERE id_pedido = %s;
            """,
            (
                id_pedido,
            )
        )


        cantidad = cursor.fetchone()[
            "total"
        ]


        # Si no quedan productos,
        # eliminamos el pedido vacío.

        
        if cantidad == 0:

            cursor.execute(
                """
                SELECT 1
                FROM pago_flow
                WHERE id_pedido = %s
                LIMIT 1;
                """,
                (id_pedido,)
            )

            tiene_historial = cursor.fetchone() is not None

            if not tiene_historial:
                cursor.execute(
                    """
                    DELETE FROM pedido
                    WHERE id_pedido = %s;
                    """,
                    (id_pedido,)
                )

                return



    # Si todavía tiene productos,
    # recalculamos el total.

    recalcular_total_pedido(
        conexion,
        id_pedido
    )