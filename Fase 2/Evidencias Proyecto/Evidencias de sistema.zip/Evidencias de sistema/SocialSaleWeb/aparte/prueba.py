"""
Prueba mínima de captura de comentarios en vivo de TikTok.

Objetivo: confirmar que se pueden recibir comentarios de un TikTok Live
en tiempo real, ANTES de construir el backend completo de SocialSale.

No hace matching de códigos ni nada de lógica de negocio todavía.
Solo se conecta al live y va imprimiendo cada comentario que llega.

------------------------------------------------------------------
CÓMO USARLO
------------------------------------------------------------------
1. Instala la librería (una sola vez):
       pip install TikTokLive

2. Reemplaza UNIQUE_ID más abajo por el @usuario de TikTok que
   esté transmitiendo en vivo en ese momento (puede ser tu propia
   cuenta, la de tu clienta, o cualquier live público activo para
   la primera prueba).

3. Ejecuta:
       python test_captura_live.py

4. Mientras el live esté activo, cada comentario que se escriba en
   el chat debería aparecer impreso en tu consola casi al instante.
   Detén el script con Ctrl+C.
------------------------------------------------------------------
"""

from TikTokLive import TikTokLiveClient
from TikTokLive.events import ConnectEvent, CommentEvent, DisconnectEvent

UNIQUE_ID = "@frekezxlk"

client = TikTokLiveClient(unique_id=UNIQUE_ID)


@client.on(ConnectEvent)
async def on_connect(event: ConnectEvent):
    print(f"[OK] Conectado al live de {UNIQUE_ID}")
    print("Esperando comentarios... (Ctrl+C para salir)\n")


@client.on(CommentEvent)
async def on_comment(event: CommentEvent):
    usuario = event.user.nickname
    texto = event.comment
    print(f"{usuario}: {texto}")

    # --- Punto de partida para la siguiente prueba ---
    # Aquí, más adelante, se agregará la lógica de negocio real, por ejemplo:
    #
    # codigo = texto.strip()
    # if codigo.isdigit() and codigo_disponible(codigo):
    #     asignar_carrito(usuario, codigo)


@client.on(DisconnectEvent)
async def on_disconnect(event: DisconnectEvent):
    print("\n[INFO] Se cerró la conexión con el live.")


if __name__ == "__main__":
    client.run()